# Architecture

## Compatibility-first contract

DualLong HyperCore does not rewrite Java's `int`, JVM descriptors, or third-party class layouts. `DualLong128` is an independent signed 128-bit two's-complement value type represented by two primitive `long` words.

The current build introduces three safe foundations:

1. A signed 128-bit arithmetic type with decimal parsing, formatting, comparison, arithmetic, shifts and fixed-width byte serialization.
2. Explicit adapters for widening old values and narrowing only with a checked or visibly saturating operation.
3. A Forge `IExtendedEntityProperties` store attached to players and persisted in entity NBT as named high/low `long` pairs.
4. A coremod loading plugin and identity transformer that audit the appearance of selected JinRyuu classes without altering their bytecode.

## Why a separate player data compound

The audited JRMCore API returns `int` from core stat methods and sends selected stats through `IMessage` classes containing `int` fields. Mutating those contracts would break old mods and clients. The sidecar data format allows a 128-bit value to persist without pretending that DBC's native combat loop already consumes it.

## Planned integration stages

- Stage A: prove numeric correctness and save/load persistence.
- Stage B: map JGPlayerMP/NBT reads and writes, stat packet handlers, scouters and HUD formatting against the exact supplied artifacts.
- Stage C: design versioned extended packets and explicit capability negotiation.
- Stage D: integrate selected gameplay paths behind per-feature switches, maintaining legacy APIs as adapters.
- Stage E: profile optimizations one subsystem at a time and require equivalence tests before enabling them by default.

## Performance policy

No global `int` opcode rewrite, no blanket object pooling, no unconditional parallel world ticking, and no claim of performance gains without repeatable benchmarks. The identity transformer is intentionally non-invasive in this milestone.
