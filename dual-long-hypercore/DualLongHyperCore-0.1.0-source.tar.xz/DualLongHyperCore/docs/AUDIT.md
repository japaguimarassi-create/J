# Binary audit: supplied Dragon Block C ecosystem

Audit basis: the seven JARs supplied for this project. The audit used ZIP metadata, class inventories and `javap -p -s` inspection. It did not modify the source JARs.

## Exact artifacts inspected

| Artifact | Version indicated by file | Minecraft target | Main mod ID found |
|---|---:|---:|---|
| `DragonBlockC-v1.4.85.jar` | 1.4.85 | 1.7.10 | `jinryuudragonblockc` |
| `JRMCore-v1.3.51.jar` | 1.3.51 | 1.7.10 | `jinryuujrmcore` |
| `JBRA-Client-v1.6.52.jar` | 1.6.52 | 1.7.10 | `jinryuubetterrenderaddon` |
| `dbcexpansion-1.3.2.jar` | 1.3.2 | 1.7.10 | `dbcexpansion` |
| `npcdbc-1.2.1.jar` | 1.2.1 | 1.7.10 | `npcdbc` |
| `dbc-CreatureBoost-0.1.1.jar` | metadata says 0.0.2; filename says 0.1.1 | 1.7.10 | `dbccb` in the `@Mod` annotation |
| `ninjinentities-Unofficial-1.4.5.jar` | 1.4.5 | 1.7.10 | `ninjinentities` |

## Input artifact fingerprints

SHA-256 hashes make the audit baseline reproducible:

| File | SHA-256 |
|---|---|
| `DragonBlockC-v1.4.85.jar` | `be8c849ab107b1126018bc5b0d0d254d751129f70f3349261f1469f0c220dc9d` |
| `JRMCore-v1.3.51.jar` | `0614265d665b6e60456d460255c1488377cad1200ad6bd9444128d835fc28946` |
| `JBRA-Client-v1.6.52.jar` | `541bc7a8063879e897a27acc3a5850b02a15f8e23ee086cb8d03a36a76e23634` |
| `dbcexpansion-1.3.2.jar` | `ef2e6a3dcbeb49c4dcf444aee38d32ccc1f2d5f21f49edace5145af7b909d2a5` |
| `npcdbc-1.2.1.jar` | `ba99440ffa25d52b10d02a54d1595777f98edb7a3c25f9ca914b88694b7ed52f` |
| `dbc-CreatureBoost-0.1.1.jar` | `ebc566d946a463a98d3c5821d3a4c44a1c6ae53c4628cd3a1132170fb6e3571d` |
| `ninjinentities-Unofficial-1.4.5.jar` | `090ce2bbb554f7aadc652567a878988a625767b81e45522cdd4384c302c0eed4` |

## Confirmed JRMCore numeric surfaces

`JinRyuu.JRMCore.server.JGPlayerMP` exposes legacy methods with `int` return values for `getAttributes`, `getLevel`, `getStat`, `getHealth`, `getHealthMax`, `getEnergy`, `getEnergyMax`, `getStamina`, `getStaminaMax`, `getEnergyPower`, and `getAttribute`. Several mutators also accept `int` values, including reserve, transformation meter and state.

`JinRyuu.JRMCore.p.JRMCorePStats` contains `int curBody`, `int curEnergy`, and `int curStamina`, plus byte fields, and its packet constructor uses descriptor `(IIIBB)V`.

`JinRyuu.JRMCore.p.JRMCorePStats2` contains `int curTP`, `int curExp`, `int[] PlyrAttrbts`, and a byte alignment field; the constructor descriptor is `(IIB[I)V`.

`JinRyuu.JRMCore.p.DBC.DBCPtick` contains an `int` field and serializes through its IMessage implementation.

`JinRyuu.JRMCore.JRMCoreH` also exposes static legacy integer fields including `kiAmount`, `dbcHealthCur`, and `BPMode`. These fields are not sufficient to prove that every player stat is stored in these globals; player state needs separate analysis through JGPlayerMP and the NBT-backed data model.

## Compatibility implications

Changing a method descriptor from `I` to `J` or to a custom object descriptor is binary-incompatible with existing compiled mods. Replacing `int[]` with another array type is also binary-incompatible. Existing Forge SimpleImpl packet layouts are not automatically compatible with wider values.

For that reason, the initial implementation stores 128-bit values in a separate player-property compound using two NBT longs (`high`, `low`). The legacy DBC/JRMCore values and packets remain untouched. A later integration phase must intercept and replace complete calculation and packet paths, not merely widen one field or clamp the displayed value.

## Known limits of this audit

This was bytecode/API inspection, not full decompilation or live gameplay testing. The audit has not established every exact arithmetic call site for Ki, power level, damage, defense, NPCDBC abilities, or addon-defined combat. No claim is made that the present release changes DBC combat values.
