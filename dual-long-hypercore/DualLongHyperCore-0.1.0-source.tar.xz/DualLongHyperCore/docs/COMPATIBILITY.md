# Compatibility matrix

The listed mod IDs were read from the supplied JAR annotations or metadata. Detection is optional; DualLong HyperCore does not require all addons.

| Mod | Mod ID | Detection in 0.1.0 | Gameplay transformation |
|---|---|---:|---:|
| JRMCore 1.3.51 | `jinryuujrmcore` | Yes | None yet |
| Dragon Block C 1.4.85 | `jinryuudragonblockc` | Yes | None yet |
| JBRA Client 1.6.52 | `jinryuubetterrenderaddon` | Yes | None yet |
| DBC Expansion 1.3.2 | `dbcexpansion` | Yes | None yet |
| NPCDBC 1.2.1 | `npcdbc` | Yes | None yet |
| CreatureBoost JAR | `dbccb` | Yes | None yet |
| Ninjin Entities 1.4.5 | `ninjinentities` | Yes | None yet |

The compatibility layer uses mod IDs, not hard links to addon classes, so absent optional mods do not cause class-loading failures.

## Current honest status

The present milestone can coexist at the class-loading level and records which core JRMCore/DBC classes are encountered. It does not modify combat, Ki, power level, entity AI, rendering, or legacy packet payloads. Live compatibility still needs to be verified in a Forge 1.7.10 instance with the exact mod pack.
