package com.dualhypercore.numeric;

import java.math.BigInteger;
import java.util.Random;
import org.junit.Test;
import static org.junit.Assert.*;

public class DualLong128Test {
    private static final BigInteger MIN = BigInteger.ONE.shiftLeft(127).negate();
    private static final BigInteger MAX = BigInteger.ONE.shiftLeft(127).subtract(BigInteger.ONE);
    private static final BigInteger MOD = BigInteger.ONE.shiftLeft(128);

    private static DualLong128 fromBig(BigInteger value) {
        BigInteger bits = value.signum() < 0 ? value.add(MOD) : value;
        byte[] raw = bits.toByteArray();
        byte[] bytes = new byte[16];
        int sourceStart = Math.max(0, raw.length - 16);
        int length = Math.min(16, raw.length);
        System.arraycopy(raw, sourceStart, bytes, 16 - length, length);
        return DualLong128.fromByteArray(bytes);
    }

    private static BigInteger toBig(DualLong128 value) {
        return new BigInteger(value.toByteArray());
    }

    @Test
    public void parsesAndFormatsBoundaries() {
        assertEquals(MIN.toString(), DualLong128.parse(MIN.toString()).toString());
        assertEquals(MAX.toString(), DualLong128.parse(MAX.toString()).toString());
        assertEquals("0", DualLong128.parse("0").toString());
        assertEquals("-1", DualLong128.parse("-1").toString());
        assertEquals("+42", "+" + DualLong128.parse("+42").toString());
    }

    @Test
    public void rejectsOutOfRangeValues() {
        assertThrows(NumberFormatException.class, () -> DualLong128.parse(MAX.add(BigInteger.ONE).toString()));
        assertThrows(NumberFormatException.class, () -> DualLong128.parse(MIN.subtract(BigInteger.ONE).toString()));
    }

    @Test
    public void arithmeticMatchesBigInteger() {
        Random random = new Random(0xD0A110L);
        for (int i = 0; i < 2500; i++) {
            BigInteger a = new BigInteger(128, random);
            BigInteger b = new BigInteger(128, random);
            if (random.nextBoolean()) a = a.negate();
            if (random.nextBoolean()) b = b.negate();
            a = a.max(MIN).min(MAX);
            b = b.max(MIN).min(MAX);
            DualLong128 da = fromBig(a);
            DualLong128 db = fromBig(b);
            assertEquals(a.add(b).mod(MOD).compareTo(BigInteger.ONE.shiftLeft(127)) >= 0 ? a.add(b).mod(MOD).subtract(MOD) : a.add(b).mod(MOD), toBig(da.add(db)));
            assertEquals(a.subtract(b).mod(MOD).compareTo(BigInteger.ONE.shiftLeft(127)) >= 0 ? a.subtract(b).mod(MOD).subtract(MOD) : a.subtract(b).mod(MOD), toBig(da.subtract(db)));
            BigInteger product = a.multiply(b).mod(MOD);
            if (product.compareTo(BigInteger.ONE.shiftLeft(127)) >= 0) product = product.subtract(MOD);
            assertEquals(product, toBig(da.multiply(db)));
            if (b.signum() != 0 && !(a.equals(MIN) && b.equals(BigInteger.valueOf(-1)))) {
                BigInteger[] qr = a.divideAndRemainder(b);
                assertEquals(qr[0], toBig(da.divide(db)));
                assertEquals(qr[1], toBig(da.remainder(db)));
            }
            assertEquals(a.toString(), da.toString());
        }
    }

    @Test
    public void shiftsAndConversions() {
        DualLong128 value = DualLong128.fromLong(-2L);
        assertEquals("-4", value.shiftLeft(1).toString());
        assertEquals("-1", value.shiftRight(1).toString());
        assertEquals(MAX.toString(), value.unsignedShiftRight(1).toString());
        assertEquals(-2L, value.longValueExact());
        assertArrayEquals(value.toByteArray(), DualLong128.fromByteArray(value.toByteArray()).toByteArray());
    }
}
