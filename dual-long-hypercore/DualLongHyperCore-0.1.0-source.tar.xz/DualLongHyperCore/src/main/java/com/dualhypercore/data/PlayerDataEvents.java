package com.dualhypercore.data;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;

public final class PlayerDataEvents {
    @SubscribeEvent
    public void onEntityConstructing(EntityEvent.EntityConstructing event) {
        if (!(event.entity instanceof EntityPlayer)) return;
        EntityPlayer player = (EntityPlayer) event.entity;
        if (player.getExtendedProperties(DualLongPlayerData.KEY) == null) {
            player.registerExtendedProperties(DualLongPlayerData.KEY, new DualLongPlayerData());
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        DualLongPlayerData oldData = DualLongPlayerData.get(event.original);
        DualLongPlayerData newData = DualLongPlayerData.get(event.entityPlayer);
        if (oldData != null && newData != null) newData.copyFrom(oldData);
    }
}
