package com.dualhypercore.config;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public final class HyperCoreConfig {
    public static boolean enableExtendedStorage = true;
    public static boolean enableClassAudit = true;
    public static boolean enablePerformanceModules = false;

    private HyperCoreConfig() {
    }

    public static void load(File file) {
        Configuration config = new Configuration(file);
        config.load();
        enableExtendedStorage = config.getBoolean("enableExtendedStorage", "general", true,
            "Stores additional 128-bit values separately from legacy DBC fields.");
        enableClassAudit = config.getBoolean("enableClassAudit", "general", true,
            "Records whether selected JRMCore and DBC classes were loaded. Does not modify bytecode.");
        enablePerformanceModules = config.getBoolean("enablePerformanceModules", "general", false,
            "Reserved for separately benchmarked optimizers. Disabled until validated.");
        if (config.hasChanged()) config.save();
    }
}
