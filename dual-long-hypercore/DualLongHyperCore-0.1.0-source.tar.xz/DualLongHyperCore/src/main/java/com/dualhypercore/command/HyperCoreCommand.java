package com.dualhypercore.command;

import com.dualhypercore.compatibility.ModCompatibility;
import com.dualhypercore.core.TargetAudit;
import com.dualhypercore.data.DualLongPlayerData;
import com.dualhypercore.data.ExtendedStat;
import com.dualhypercore.numeric.DualLong128;
import java.util.Locale;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;

public final class HyperCoreCommand extends CommandBase {
    @Override
    public String getCommandName() {
        return "dlhc";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/dlhc status | get <stat> | set <stat> <integer128>";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0 || "status".equalsIgnoreCase(args[0])) {
            showStatus(sender);
            return;
        }
        if (args.length >= 2 && "get".equalsIgnoreCase(args[0])) {
            EntityPlayer player = getSenderPlayer(sender);
            ExtendedStat stat = parseStat(args[1]);
            DualLongPlayerData data = DualLongPlayerData.get(player);
            if (data == null) throw new CommandException("Extended numeric storage is unavailable.");
            sender.addChatMessage(new ChatComponentText("[DualLong] " + stat.name() + " = " + data.get(stat)));
            return;
        }
        if (args.length == 3 && "set".equalsIgnoreCase(args[0])) {
            EntityPlayer player = getSenderPlayer(sender);
            ExtendedStat stat = parseStat(args[1]);
            DualLong128 value;
            try {
                value = DualLong128.parse(args[2]);
            } catch (NumberFormatException exception) {
                throw new CommandException("Invalid signed 128-bit integer: " + args[2]);
            }
            DualLongPlayerData data = DualLongPlayerData.get(player);
            if (data == null) throw new CommandException("Extended numeric storage is unavailable.");
            data.set(stat, value);
            sender.addChatMessage(new ChatComponentText("[DualLong] Stored " + stat.name() + " = " + value));
            return;
        }
        throw new CommandException(getCommandUsage(sender));
    }

    private static EntityPlayer getSenderPlayer(ICommandSender sender) throws CommandException {
        return CommandBase.getCommandSenderAsPlayer(sender);
    }

    private static ExtendedStat parseStat(String value) throws CommandException {
        try {
            return ExtendedStat.valueOf(value.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            throw new CommandException("Unknown stat. Valid values: POWER_LEVEL, KI, HEALTH, ENERGY, STAMINA, DAMAGE, DEFENSE, EXPERIENCE, TRAINING_POINTS");
        }
    }

    private static void showStatus(ICommandSender sender) {
        ModCompatibility.Snapshot mods = ModCompatibility.detect();
        sender.addChatMessage(new ChatComponentText("[DualLong] Core pair detected: " + mods.hasCorePair()));
        sender.addChatMessage(new ChatComponentText("[DualLong] Audited classes seen: " + TargetAudit.getSeenCount()));
        for (String line : mods.describe()) sender.addChatMessage(new ChatComponentText("[DualLong] " + line));
    }
}
