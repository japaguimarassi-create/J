package com.dualhypercore.compatibility;

import cpw.mods.fml.common.Loader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModCompatibility {
    private static final String JRMCORE = "jinryuujrmcore";
    private static final String DBC = "jinryuudragonblockc";
    private static final String JBRA = "jinryuubetterrenderaddon";

    private ModCompatibility() {
    }

    public static Snapshot detect() {
        return new Snapshot(
            loaded(JRMCORE),
            loaded(DBC),
            loaded(JBRA),
            loaded("dbcexpansion"),
            loaded("npcdbc"),
            loaded("dbccb"),
            loaded("ninjinentities")
        );
    }

    private static boolean loaded(String modId) {
        return Loader.isModLoaded(modId);
    }

    public static final class Snapshot {
        public final boolean jrmCore;
        public final boolean dbc;
        public final boolean jbra;
        public final boolean dbcExpansion;
        public final boolean npcDbc;
        public final boolean creatureBoost;
        public final boolean ninjinEntities;

        private Snapshot(boolean jrmCore, boolean dbc, boolean jbra, boolean dbcExpansion, boolean npcDbc, boolean creatureBoost, boolean ninjinEntities) {
            this.jrmCore = jrmCore;
            this.dbc = dbc;
            this.jbra = jbra;
            this.dbcExpansion = dbcExpansion;
            this.npcDbc = npcDbc;
            this.creatureBoost = creatureBoost;
            this.ninjinEntities = ninjinEntities;
        }

        public boolean hasCorePair() {
            return jrmCore && dbc;
        }

        public List<String> describe() {
            List<String> result = new ArrayList<String>();
            result.add("JRMCore: " + state(jrmCore));
            result.add("Dragon Block C: " + state(dbc));
            result.add("JBRA Client: " + state(jbra));
            result.add("DBC Expansion: " + state(dbcExpansion));
            result.add("NPCDBC: " + state(npcDbc));
            result.add("CreatureBoost: " + state(creatureBoost));
            result.add("Ninjin Entities: " + state(ninjinEntities));
            return Collections.unmodifiableList(result);
        }

        private static String state(boolean loaded) {
            return loaded ? "loaded" : "not detected";
        }
    }
}
