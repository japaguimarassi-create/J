package com.dualhypercore.core;

import net.minecraft.launchwrapper.IClassTransformer;

public final class HyperCoreTransformer implements IClassTransformer {
    @Override
    public byte[] transform(String name, String transformedName, byte[] basicClass) {
        TargetAudit.record(transformedName != null ? transformedName : name);
        return basicClass;
    }
}
