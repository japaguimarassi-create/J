package com.dualhypercore.data;

import com.dualhypercore.numeric.DualLong128;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.common.IExtendedEntityProperties;

public final class DualLongPlayerData implements IExtendedEntityProperties {
    public static final String KEY = "DualLongHyperCore";
    private final DualLong128[] values = new DualLong128[ExtendedStat.values().length];

    public DualLongPlayerData() {
        for (int i = 0; i < values.length; i++) values[i] = DualLong128.ZERO;
    }

    public DualLong128 get(ExtendedStat stat) {
        return values[stat.ordinal()];
    }

    public void set(ExtendedStat stat, DualLong128 value) {
        if (stat == null || value == null) throw new NullPointerException();
        values[stat.ordinal()] = value;
    }

    public void copyFrom(DualLongPlayerData source) {
        for (int i = 0; i < values.length; i++) values[i] = source.values[i];
    }

    @Override
    public void saveNBTData(NBTTagCompound entityTag) {
        NBTTagCompound data = new NBTTagCompound();
        for (ExtendedStat stat : ExtendedStat.values()) {
            DualLong128 value = get(stat);
            NBTTagCompound number = new NBTTagCompound();
            number.setLong("high", value.high());
            number.setLong("low", value.low());
            data.setTag(stat.name(), number);
        }
        entityTag.setTag(KEY, data);
    }

    @Override
    public void loadNBTData(NBTTagCompound entityTag) {
        if (!entityTag.hasKey(KEY, 10)) return;
        NBTTagCompound data = entityTag.getCompoundTag(KEY);
        for (ExtendedStat stat : ExtendedStat.values()) {
            if (!data.hasKey(stat.name(), 10)) continue;
            NBTTagCompound number = data.getCompoundTag(stat.name());
            values[stat.ordinal()] = DualLong128.of(number.getLong("high"), number.getLong("low"));
        }
    }

    @Override
    public void init(Entity entity, World world) {
    }

    public static DualLongPlayerData get(EntityPlayer player) {
        if (player == null) return null;
        Object properties = player.getExtendedProperties(KEY);
        return properties instanceof DualLongPlayerData ? (DualLongPlayerData) properties : null;
    }
}
