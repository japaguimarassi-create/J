package com.dualhypercore.data;

public enum ExtendedStat {
    POWER_LEVEL,
    KI,
    HEALTH,
    ENERGY,
    STAMINA,
    DAMAGE,
    DEFENSE,
    EXPERIENCE,
    TRAINING_POINTS
}
