package com.dualhypercore.core;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class TargetAudit {
    private static final Set<String> TARGETS = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private static volatile boolean enabled = true;

    private TargetAudit() {
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        if (!value) TARGETS.clear();
    }

    public static void record(String transformedName) {
        if (!enabled || transformedName == null) return;
        if (isTarget(transformedName)) TARGETS.add(transformedName);
    }

    private static boolean isTarget(String className) {
        return "JinRyuu.JRMCore.server.JGPlayerMP".equals(className)
            || "JinRyuu.JRMCore.p.JRMCorePStats".equals(className)
            || "JinRyuu.JRMCore.p.JRMCorePStats2".equals(className)
            || "JinRyuu.JRMCore.p.DBC.DBCPtick".equals(className)
            || "JinRyuu.JRMCore.JRMCoreH".equals(className)
            || "JinRyuu.DragonBC.common.DBCKiAttacks".equals(className)
            || "JinRyuu.DragonBC.common.DBCCommonTickHandler".equals(className);
    }

    public static int getSeenCount() {
        return TARGETS.size();
    }

    public static Set<String> snapshot() {
        return Collections.unmodifiableSet(TARGETS);
    }
}
