package com.dualhypercore.numeric;

public final class NumericAdapter {
    private NumericAdapter() {
    }

    public static DualLong128 promote(int value) {
        return DualLong128.fromLong(value);
    }

    public static DualLong128 promote(long value) {
        return DualLong128.fromLong(value);
    }

    public static int narrowIntExact(DualLong128 value) {
        if (value == null) throw new NullPointerException("value");
        long narrowed = value.longValueExact();
        if (narrowed < Integer.MIN_VALUE || narrowed > Integer.MAX_VALUE) {
            throw new ArithmeticException("Value does not fit in signed 32 bits");
        }
        return (int) narrowed;
    }

    public static int narrowIntSaturated(DualLong128 value) {
        if (value == null) throw new NullPointerException("value");
        if (value.compareTo(DualLong128.fromLong(Integer.MAX_VALUE)) > 0) return Integer.MAX_VALUE;
        if (value.compareTo(DualLong128.fromLong(Integer.MIN_VALUE)) < 0) return Integer.MIN_VALUE;
        return (int) value.longValue();
    }

    public static long narrowLongExact(DualLong128 value) {
        if (value == null) throw new NullPointerException("value");
        return value.longValueExact();
    }
}
