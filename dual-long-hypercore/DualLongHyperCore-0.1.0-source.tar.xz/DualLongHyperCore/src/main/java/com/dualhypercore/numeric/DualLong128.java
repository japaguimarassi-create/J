package com.dualhypercore.numeric;

import java.nio.ByteBuffer;

public final class DualLong128 implements Comparable<DualLong128> {
    public static final DualLong128 ZERO = new DualLong128(0L, 0L);
    public static final DualLong128 ONE = new DualLong128(0L, 1L);
    public static final DualLong128 TEN = new DualLong128(0L, 10L);
    public static final DualLong128 MIN_VALUE = new DualLong128(Long.MIN_VALUE, 0L);
    public static final DualLong128 MAX_VALUE = new DualLong128(Long.MAX_VALUE, -1L);

    private final long high;
    private final long low;

    private DualLong128(long high, long low) {
        this.high = high;
        this.low = low;
    }

    public static DualLong128 of(long high, long low) {
        if (high == 0L && low == 0L) return ZERO;
        if (high == 0L && low == 1L) return ONE;
        return new DualLong128(high, low);
    }

    public static DualLong128 fromLong(long value) {
        return of(value < 0L ? -1L : 0L, value);
    }

    public static DualLong128 fromByteArray(byte[] bytes) {
        if (bytes == null || bytes.length != 16) throw new IllegalArgumentException("Expected exactly 16 bytes");
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        return of(buffer.getLong(), buffer.getLong());
    }

    public static DualLong128 parse(String value) {
        if (value == null || value.length() == 0) throw new NumberFormatException("Empty value");
        int index = 0;
        boolean negative = false;
        char first = value.charAt(0);
        if (first == '-' || first == '+') {
            negative = first == '-';
            index++;
        }
        if (index == value.length()) throw new NumberFormatException("Sign without digits");
        DualLong128 limit = negative ? MIN_VALUE : MAX_VALUE.negate();
        DualLong128 multiplyLimit = limit.divide(TEN);
        DualLong128 result = ZERO;
        for (; index < value.length(); index++) {
            char c = value.charAt(index);
            if (c < '0' || c > '9') throw new NumberFormatException("Invalid decimal digit: " + c);
            int digit = c - '0';
            if (result.compareTo(multiplyLimit) < 0) throw new NumberFormatException("Value exceeds signed 128-bit range");
            result = result.multiply(TEN);
            DualLong128 threshold = limit.add(fromLong(digit));
            if (result.compareTo(threshold) < 0) throw new NumberFormatException("Value exceeds signed 128-bit range");
            result = result.subtract(fromLong(digit));
        }
        return negative ? result : result.negate();
    }

    public long high() {
        return high;
    }

    public long low() {
        return low;
    }

    public boolean isZero() {
        return high == 0L && low == 0L;
    }

    public boolean isNegative() {
        return high < 0L;
    }

    public DualLong128 add(DualLong128 other) {
        if (other == null) throw new NullPointerException("other");
        long resultLow = low + other.low;
        long carry = Long.compareUnsigned(resultLow, low) < 0 ? 1L : 0L;
        return of(high + other.high + carry, resultLow);
    }

    public DualLong128 addExact(DualLong128 other) {
        DualLong128 result = add(other);
        if (((high ^ other.high) >= 0L) && ((high ^ result.high) < 0L)) {
            throw new ArithmeticException("signed 128-bit overflow");
        }
        return result;
    }

    public DualLong128 subtract(DualLong128 other) {
        if (other == null) throw new NullPointerException("other");
        long resultLow = low - other.low;
        long borrow = Long.compareUnsigned(low, other.low) < 0 ? 1L : 0L;
        return of(high - other.high - borrow, resultLow);
    }

    public DualLong128 subtractExact(DualLong128 other) {
        DualLong128 result = subtract(other);
        if (((high ^ other.high) < 0L) && ((high ^ result.high) < 0L)) {
            throw new ArithmeticException("signed 128-bit overflow");
        }
        return result;
    }

    public DualLong128 negate() {
        long resultLow = -low;
        long resultHigh = ~high + (resultLow == 0L ? 1L : 0L);
        return of(resultHigh, resultLow);
    }

    public DualLong128 abs() {
        return isNegative() ? negate() : this;
    }

    public DualLong128 multiply(DualLong128 other) {
        if (other == null) throw new NullPointerException("other");
        long resultLow = low * other.low;
        long resultHigh = unsignedMultiplyHigh(low, other.low) + high * other.low + low * other.high;
        return of(resultHigh, resultLow);
    }

    private static long unsignedMultiplyHigh(long x, long y) {
        long x0 = x & 0xffffffffL;
        long x1 = x >>> 32;
        long y0 = y & 0xffffffffL;
        long y1 = y >>> 32;
        long w0 = x0 * y0;
        long t = x1 * y0 + (w0 >>> 32);
        long w1 = t & 0xffffffffL;
        long w2 = t >>> 32;
        w1 += x0 * y1;
        return x1 * y1 + w2 + (w1 >>> 32);
    }

    public DualLong128 divide(DualLong128 divisor) {
        return divideAndRemainder(divisor).quotient;
    }

    public DualLong128 remainder(DualLong128 divisor) {
        return divideAndRemainder(divisor).remainder;
    }

    public Division divideAndRemainder(DualLong128 divisor) {
        if (divisor == null) throw new NullPointerException("divisor");
        if (divisor.isZero()) throw new ArithmeticException("division by zero");
        if (equals(MIN_VALUE) && divisor.equals(fromLong(-1L))) {
            throw new ArithmeticException("signed 128-bit division overflow");
        }
        boolean quotientNegative = isNegative() ^ divisor.isNegative();
        boolean remainderNegative = isNegative();
        DualLong128 dividendMagnitude = abs();
        DualLong128 divisorMagnitude = divisor.abs();
        Division unsigned = divideUnsigned(dividendMagnitude, divisorMagnitude);
        DualLong128 quotient = quotientNegative ? unsigned.quotient.negate() : unsigned.quotient;
        DualLong128 remainder = remainderNegative ? unsigned.remainder.negate() : unsigned.remainder;
        return new Division(quotient, remainder);
    }

    private static Division divideUnsigned(DualLong128 dividend, DualLong128 divisor) {
        long quotientHigh = 0L;
        long quotientLow = 0L;
        long remainderHigh = 0L;
        long remainderLow = 0L;
        for (int bit = 127; bit >= 0; bit--) {
            boolean carry = remainderHigh < 0L;
            remainderHigh = (remainderHigh << 1) | (remainderLow >>> 63);
            remainderLow = (remainderLow << 1) | dividend.bitAt(bit);
            if (carry || compareUnsigned(remainderHigh, remainderLow, divisor.high, divisor.low) >= 0) {
                long oldLow = remainderLow;
                remainderLow -= divisor.low;
                long borrow = Long.compareUnsigned(oldLow, divisor.low) < 0 ? 1L : 0L;
                remainderHigh = remainderHigh - divisor.high - borrow;
                if (bit >= 64) quotientHigh |= 1L << (bit - 64);
                else quotientLow |= 1L << bit;
            }
        }
        return new Division(of(quotientHigh, quotientLow), of(remainderHigh, remainderLow));
    }

    private static int compareUnsigned(long ah, long al, long bh, long bl) {
        int highComparison = Long.compareUnsigned(ah, bh);
        return highComparison != 0 ? highComparison : Long.compareUnsigned(al, bl);
    }

    private long bitAt(int index) {
        return index >= 64 ? ((high >>> (index - 64)) & 1L) : ((low >>> index) & 1L);
    }

    public DualLong128 shiftLeft(int distance) {
        int shift = distance & 127;
        if (shift == 0) return this;
        if (shift >= 64) return of(low << (shift - 64), 0L);
        return of((high << shift) | (low >>> (64 - shift)), low << shift);
    }

    public DualLong128 shiftRight(int distance) {
        int shift = distance & 127;
        if (shift == 0) return this;
        if (shift >= 64) return of(high < 0L ? -1L : 0L, high >> (shift - 64));
        return of(high >> shift, (low >>> shift) | (high << (64 - shift)));
    }

    public DualLong128 unsignedShiftRight(int distance) {
        int shift = distance & 127;
        if (shift == 0) return this;
        if (shift >= 64) return of(0L, high >>> (shift - 64));
        return of(high >>> shift, (low >>> shift) | (high << (64 - shift)));
    }

    public boolean toBoolean() {
        return !isZero();
    }

    public long longValueExact() {
        if ((high == 0L && low >= 0L) || (high == -1L && low < 0L)) return low;
        throw new ArithmeticException("Value does not fit in signed 64 bits");
    }

    public long longValue() {
        return low;
    }

    public int intValue() {
        return (int) low;
    }

    public byte[] toByteArray() {
        return ByteBuffer.allocate(16).putLong(high).putLong(low).array();
    }

    private Division divideUnsignedBySmall(int divisor) {
        long[] words = new long[] { (high >>> 32) & 0xffffffffL, high & 0xffffffffL, (low >>> 32) & 0xffffffffL, low & 0xffffffffL };
        long[] quotient = new long[4];
        long remainder = 0L;
        for (int i = 0; i < 4; i++) {
            long current = (remainder << 32) | words[i];
            quotient[i] = current / divisor;
            remainder = current % divisor;
        }
        DualLong128 q = of((quotient[0] << 32) | quotient[1], (quotient[2] << 32) | quotient[3]);
        return new Division(q, fromLong(remainder));
    }

    @Override
    public int compareTo(DualLong128 other) {
        int highComparison = Long.compare(high, other.high);
        return highComparison != 0 ? highComparison : Long.compareUnsigned(low, other.low);
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof DualLong128)) return false;
        DualLong128 other = (DualLong128) object;
        return high == other.high && low == other.low;
    }

    @Override
    public int hashCode() {
        int result = (int) (high ^ (high >>> 32));
        result = 31 * result + (int) (low ^ (low >>> 32));
        return result;
    }

    @Override
    public String toString() {
        if (isZero()) return "0";
        boolean negative = isNegative();
        DualLong128 current = abs();
        char[] buffer = new char[40];
        int position = buffer.length;
        while (!current.isZero()) {
            Division division = current.divideUnsignedBySmall(10);
            buffer[--position] = (char) ('0' + division.remainder.low);
            current = division.quotient;
        }
        if (negative) buffer[--position] = '-';
        return new String(buffer, position, buffer.length - position);
    }

    public static final class Division {
        public final DualLong128 quotient;
        public final DualLong128 remainder;

        private Division(DualLong128 quotient, DualLong128 remainder) {
            this.quotient = quotient;
            this.remainder = remainder;
        }
    }
}
