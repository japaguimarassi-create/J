package com.dualhypercore;

import com.dualhypercore.command.HyperCoreCommand;
import com.dualhypercore.config.HyperCoreConfig;
import com.dualhypercore.data.PlayerDataEvents;
import com.dualhypercore.compatibility.ModCompatibility;
import com.dualhypercore.core.TargetAudit;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.common.MinecraftForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(modid = DualLongHyperCore.MOD_ID, name = "DualLong HyperCore", version = "0.1.0", acceptedMinecraftVersions = "[1.7.10]", dependencies = "after:jinryuujrmcore;after:jinryuudragonblockc;after:jinryuubetterrenderaddon")
public final class DualLongHyperCore {
    public static final String MOD_ID = "duallonghypercore";
    public static final Logger LOG = LogManager.getLogger("DualLongHyperCore");

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        HyperCoreConfig.load(event.getSuggestedConfigurationFile());
        if (HyperCoreConfig.enableExtendedStorage) MinecraftForge.EVENT_BUS.register(new PlayerDataEvents());
        TargetAudit.setEnabled(HyperCoreConfig.enableClassAudit);
        ModCompatibility.Snapshot mods = ModCompatibility.detect();
        LOG.info("DualLong HyperCore 0.1.0 initialized for Minecraft 1.7.10");
        for (String line : mods.describe()) LOG.info(line);
        if (mods.dbc && !mods.jrmCore) LOG.warn("Dragon Block C was detected without JRMCore; DBC integration is disabled.");
        if (mods.hasCorePair()) LOG.info("DBC/JRMCore pair detected. Extended data remains isolated from legacy gameplay fields in this build.");
    }

    @Mod.EventHandler
    public void onServerStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new HyperCoreCommand());
    }
}
