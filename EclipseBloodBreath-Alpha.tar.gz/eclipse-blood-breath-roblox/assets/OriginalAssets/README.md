# Original asset inventory

The alpha intentionally starts without imported meshes, textures, animations or audio. Procedural Roblox geometry is used for the first playable slice so there are no unclear asset rights or hidden script dependencies.

When adding production assets, record for each one:

- asset name and in-game use;
- creator/source and original file path;
- license or written permission;
- Roblox asset ID after upload;
- mobile texture/triangle/memory budget;
- fallback or low-effects version.

Do not place Demon Slayer footage, ripped models, music, dialogue, screenshots or extracted animation in this folder.
