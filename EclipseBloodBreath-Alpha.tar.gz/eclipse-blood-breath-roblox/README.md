# ECLIPSE: BLOOD & BREATH

**Roblox Action RPG — vertical slice alpha**

A dark-fantasy action RPG about two original paths: the **Guardião**, who fights through disciplined weapon schools, and the **Criatura**, who channels an unstable supernatural art. The game takes the broad themes of dangerous night journeys, specialized combat schools, rival factions and cinematic duels as inspiration; its world, names, characters, abilities, assets and narrative are original.

## What is implemented in this branch

- A generated first region: starting village, dojo/training yard, forest route and a separate boss arena.
- First-session choice between Guardião and Criatura, stored in the player profile.
- Server-authoritative light/heavy attacks, block, dodge and one faction-specific skill.
- Enemy AI with pursuit, wind-up cues, basic attacks and a multi-target boss attack.
- A three-enemy introductory trial, XP, levels, rank titles, gold and style mastery.
- Active training with server cooldowns and reduced value compared with combat rewards.
- A custom Portuguese HUD, keyboard/mouse controls and touch buttons.
- DataStore profile loading/saving with a safe temporary-session fallback if loading fails. A failed read is never written back as a fresh profile.
- A Rojo project and GitHub Actions workflow that builds an `.rbxlx` place artifact.

## Project layout

```text
default.project.json
src/
  shared/Config.lua
  server/Bootstrap.server.lua
  server/Services/
  client/ClientBootstrap.client.lua
docs/
  GAME_BIBLE.md
  IMPLEMENTATION_STATUS.md
  RESEARCH_LOG.md
.github/workflows/build-place.yml
```

## Build the place

This repository uses [Rojo](https://rojo.space/) to map Luau source into a Roblox place file.

```bash
rojo build default.project.json --output build/EclipseBloodBreath.rbxlx
```

To iterate in Studio, run `rojo serve` from this folder and connect the Rojo Studio plugin. The GitHub Actions workflow also creates `EclipseBloodBreath.rbxlx` as a downloadable build artifact after a push to this branch.

## DataStore setup

For persistent saves in a Studio test session, publish the test experience and enable **Game Settings → Security → Enable Studio Access to API Services**. Without that permission, the game remains playable in a temporary session, but the HUD reports that progress will not persist.

## Controls

| Action | PC | Touch |
|---|---|---|
| Ataque leve | Mouse 1 | LEVE |
| Ataque pesado | Mouse 2 | PESADO |
| Bloqueio | F (hold) | DEFESA (hold) |
| Esquiva | Q | ESQUIVA |
| Habilidade | E | HABILIDADE |
| Treinar | T | TREINO |
| Aceitar prova | G | PROVA |

## Important limits of this alpha

This is a real source project and a playable-slice implementation, not a published Roblox experience. It still needs a Roblox Studio build/test session, two-client multiplayer tests, mobile-device profiling, final 3D character/weapon meshes, authored animation assets, sound, and a release review. The current world and enemy rigs are procedurally assembled from Roblox parts so the first build does not depend on unlicensed external assets.

No Demon Slayer character, title, logo, music, voice, model, map, named technique or extracted footage is included. The title is provisional and should be checked before release.
