# Research log

Consulted: 2026-11-06.

## Caverna da IA — AI-assisted game creation workflow

- Source: [Como Criar Seu Próprio Jogo estilo Pokémon do Zero](https://www.youtube.com/watch?v=OlsXmHRxOEw), Caverna da IA, 2026-09-03.
- Public research summary: [Glasp summary](https://glasp.co/youtube/OlsXmHRxOEw).
- Observed method from the public summary: a large structured prompt; separate research/context/game-bible documents; original creatures and assets rather than direct franchise copying; staged map and gameplay implementation; GitHub checkpoints; repeated translation, playtesting and bug-fixing.
- Application here: this repository contains a game bible, implementation status, research log, modular Luau services, original faction/style names, a procedural first region and a CI build path. Work is deliberately scoped to a vertical slice before adding the full world.
- Limitation: the public summary is not a frame-by-frame inspection of the full video. No timestamps or unverified claims about the creator's exact implementation are asserted.

## Roblox genre benchmark

The uploaded product dossier compares Demonfall, Project Slayers, Rogue Demon, Slayers 2, Slayer Battlegrounds, Demon Soul Simulator and other experiences. The alpha applies only broad design observations: meaningful faction choice, mobile controls, short arena-style combat, RPG progression and immediate rewards. It does not reproduce their maps, interfaces, movesets, assets or exact progression.

## IP and production rule

The supplied dossier requires an original or properly licensed route. This alpha follows the original route: original names, factions, styles, enemies, map and effects. It does not import anime footage, character models, music, voice lines, logos or named techniques.
