# Game Bible — ECLIPSE: BLOOD & BREATH

## Product pillars

1. Responsive action combat with readable startup, active and recovery windows.
2. Two meaningful factions with different resource loops and signature skills.
3. Short-session progress that feeds into level, rank, mastery and later Ascension.
4. A mobile-first interface that does not hide the world or cover the target.
5. Original art, names, sounds, story and worldbuilding.

## World and opening loop

The playable slice opens in the **Vila do Primeiro Juramento**. Players can inspect the dojo and training yard, follow the lantern path into the **Bosque dos Sinos**, and reach the **Arena da Fenda**, where the Sentinela da Fenda waits.

The first loop is: choose a faction → learn movement and attacks → accept the First Trial → defeat three Sombra Errantes → earn XP, gold and mastery → challenge the boss.

## Factions

### Guardião

- Combat identity: measured sword pressure, spacing and counterplay.
- Style: **Escola da Maré**.
- Signature: **Corte da Maré**, a wide forward wave with visible wind-up and recovery.
- Strength: reach and consistent multi-target pressure.

### Criatura

- Combat identity: unstable close-range supernatural pressure.
- Style: **Arte do Abismo**.
- Signature: **Pulso Abissal**, a radial burst around the player.
- Strength: close-range area control.
- Limitation: the same energy budget and cooldown constraints apply; no infinite regeneration.

The names above are original working names and should be checked for conflicts before release.

## Combat rules in the alpha

- Light attack: 13 base damage, 0.42 s cooldown.
- Heavy attack: 27 base damage, 1.15 s cooldown, slower startup.
- Skill: 39 base damage, 35 energy, 7 s cooldown.
- Dodge: 12 energy, 1.05 s cooldown, short server-set dodge window.
- Block: reduces incoming enemy damage; it does not eliminate it.
- The server checks action, faction, cooldown, energy, character state and target hitbox. The client only requests actions and displays feedback.
- PvP is intentionally disabled in this vertical slice.

## Progression

Profile dimensions remain distinct:

- Level: general XP progression.
- Rank: title determined by level thresholds in this slice.
- Style mastery: increases through correct combat and training.
- Ascension: planned for a later milestone and not implemented here.

The First Trial asks for three common enemy defeats. The boss is an optional challenge for this first build and grants a larger reward.

## Visual direction

Stylized 3D dark fantasy with warm lantern pools, cool moonlit shadows, restrained mist, readable silhouettes and limited combat particles. The village uses timber, stone, paper lanterns and simple roof geometry; the forest uses tall trunks, layered canopies and clear paths; the boss arena uses a strong circular landmark. Bright skill effects must not obscure telegraphs.

The alpha builds its environment and NPC silhouettes from native Parts. Final production should replace these with original optimized meshes and authored animation/VFX assets.

## Interface and accessibility

- Portuguese (Brazil) by default.
- Touch buttons are large and grouped in the lower-right corner.
- Desktop controls use mouse and keyboard.
- HUD displays health, energy, XP, faction, rank, quest progress and data-save status.
- Future settings: camera shake, flashes, particle density, audio groups, button scaling and controller remapping.

## Future milestones

1. **Vertical slice:** first hub, one forest route, two factions, basic combat, one common enemy type, one boss, one mission, save profile and touch HUD.
2. **Initial progression:** faction missions, more training trials, deeper ranks, skill branches, inventory and two more regions.
3. **Competition/endgame:** fair arena modes, matchmaking, raids, Ascension and guild/companies.
4. **Release:** final original models, animations/audio, mobile profiling, security review, content-maturity questionnaire, moderation and release assets.
