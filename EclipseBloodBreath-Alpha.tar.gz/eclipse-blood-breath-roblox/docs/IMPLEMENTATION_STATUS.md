# Implementation status

## Included in the alpha source

- [x] Rojo place project and folder mapping.
- [x] Shared gameplay configuration.
- [x] RemoteEvent creation on the server.
- [x] Player profile schema, migrations, safe load fallback and periodic saves.
- [x] Faction selection and persistence.
- [x] Procedural first-region map and spawn points.
- [x] Common enemy and boss procedural rigs.
- [x] Enemy pursuit, attack wind-up and boss area attack.
- [x] Server-validated light/heavy attacks, block, dodge and faction skill.
- [x] XP, levels, rank title, gold and mastery.
- [x] First Trial quest and training cooldown.
- [x] Portuguese HUD and keyboard/touch controls.
- [x] GitHub Actions Rojo build workflow.

## Not verified in this environment

- [ ] Rojo build executed in GitHub Actions.
- [ ] Runtime validation in Roblox Studio.
- [ ] Two-client multiplayer test.
- [ ] Actual Android/iOS performance test.
- [ ] DataStore round-trip test in a published test place.
- [ ] Exploit/rate-limit test against hostile clients.
- [ ] Final art, animation and sound integration.

## Known alpha limitations

- No player-versus-player combat, ranked queue, inventory, forge, clans or Ascension yet.
- NPCs use procedural welded-part rigs; they need final meshes and authored animations.
- The map is a compact first region, not the complete world described in the product dossier.
- The First Trial is a single repeatable quest; there are not yet separate faction storylines.
- Default Roblox character movement is retained; advanced locomotion, lock-on and controller remapping are not part of this slice.
- Save failure intentionally disables persistence for that session instead of risking overwriting unread player data.

A box is checked only when source code exists. The unchecked items require an actual Roblox/CI environment and must not be represented as completed.
