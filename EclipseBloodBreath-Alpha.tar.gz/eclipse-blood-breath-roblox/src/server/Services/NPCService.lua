local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local NPCService = {}

local progressionService
local questService
local remotes
local enemyFolder

local function makeBodyPart(model, name, size, cframe, color, material, root, shape)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = material
	part.Anchored = false
	part.CanCollide = false
	part.Massless = true
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	if shape then
		part.Shape = shape
	end
	part.Parent = model

	local weld = Instance.new("WeldConstraint")
	weld.Part0 = root
	weld.Part1 = part
	weld.Parent = part
	return part
end

local function makeEnemy(name, position, isBoss)
	local settings = isBoss and Config.Enemies.Boss or Config.Enemies.Common
	local scale = isBoss and 1.55 or 1
	local model = Instance.new("Model")
	model.Name = name
	model:SetAttribute("IsEnemy", true)
	model:SetAttribute("IsBoss", isBoss)
	model:SetAttribute("EnemyType", isBoss and "Boss" or "Common")
	model:SetAttribute("LastHitBy", 0)

	local root = Instance.new("Part")
	root.Name = "HumanoidRootPart"
	root.Size = Vector3.new(2, 4, 2) * scale
	root.CFrame = CFrame.new(position)
	root.Transparency = 1
	root.Anchored = false
	root.CanCollide = true
	root.Parent = model
	model.PrimaryPart = root

	local bodyColor = settings.Color
	local body = makeBodyPart(model, "Torso", Vector3.new(2.2, 2.4, 1.3) * scale, root.CFrame * CFrame.new(0, 0.1 * scale, 0), bodyColor, Enum.Material.Slate, root)
	local head = makeBodyPart(model, "Head", Vector3.new(1.5, 1.5, 1.5) * scale, root.CFrame * CFrame.new(0, 2.05 * scale, 0), Color3.fromRGB(35, 35, 49), Enum.Material.SmoothPlastic, root, Enum.PartType.Ball)
	makeBodyPart(model, "LeftArm", Vector3.new(0.75, 2.3, 0.8) * scale, root.CFrame * CFrame.new(-1.45 * scale, 0.1 * scale, 0), bodyColor, Enum.Material.Slate, root)
	makeBodyPart(model, "RightArm", Vector3.new(0.75, 2.3, 0.8) * scale, root.CFrame * CFrame.new(1.45 * scale, 0.1 * scale, 0), bodyColor, Enum.Material.Slate, root)
	makeBodyPart(model, "LeftLeg", Vector3.new(0.85, 2.1, 0.9) * scale, root.CFrame * CFrame.new(-0.58 * scale, -0.9 * scale, 0), Color3.fromRGB(39, 39, 55), Enum.Material.Slate, root)
	makeBodyPart(model, "RightLeg", Vector3.new(0.85, 2.1, 0.9) * scale, root.CFrame * CFrame.new(0.58 * scale, -0.9 * scale, 0), Color3.fromRGB(39, 39, 55), Enum.Material.Slate, root)

	local eyes = makeBodyPart(model, "EyeGlow", Vector3.new(0.85, 0.16, 0.12) * scale, root.CFrame * CFrame.new(0, 2.05 * scale, -0.69 * scale), isBoss and Color3.fromRGB(255, 73, 133) or Color3.fromRGB(133, 194, 255), Enum.Material.Neon, root)
	eyes.CanCollide = false

	local humanoid = Instance.new("Humanoid")
	humanoid.Name = "Humanoid"
	humanoid.MaxHealth = settings.Health
	humanoid.Health = settings.Health
	humanoid.WalkSpeed = settings.WalkSpeed
	humanoid.HipHeight = 1 * scale
	humanoid.AutoRotate = true
	humanoid.BreakJointsOnDeath = false
	humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	humanoid.Parent = model

	local animator = Instance.new("Animator")
	animator.Parent = humanoid

	local billboard = Instance.new("BillboardGui")
	billboard.Name = "EnemyTag"
	billboard.Adornee = head
	billboard.Size = UDim2.fromOffset(isBoss and 230 or 170, isBoss and 42 or 32)
	billboard.StudsOffset = Vector3.new(0, 1.8 * scale, 0)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 110
	billboard.Parent = model

	local nameLabel = Instance.new("TextLabel")
	nameLabel.Name = "NameLabel"
	nameLabel.Size = UDim2.fromScale(1, 0.58)
	nameLabel.BackgroundTransparency = 1
	nameLabel.Text = name
	nameLabel.TextColor3 = isBoss and Color3.fromRGB(255, 126, 164) or Color3.fromRGB(224, 231, 255)
	nameLabel.TextScaled = true
	nameLabel.Font = Enum.Font.GothamBold
	nameLabel.Parent = billboard

	local healthBack = Instance.new("Frame")
	healthBack.Name = "HealthBack"
	healthBack.Position = UDim2.fromScale(0.08, 0.65)
	healthBack.Size = UDim2.fromScale(0.84, 0.2)
	healthBack.BackgroundColor3 = Color3.fromRGB(29, 25, 37)
	healthBack.BorderSizePixel = 0
	healthBack.Parent = billboard

	local healthFill = Instance.new("Frame")
	healthFill.Name = "HealthFill"
	healthFill.Size = UDim2.fromScale(1, 1)
	healthFill.BackgroundColor3 = isBoss and Color3.fromRGB(205, 69, 119) or Color3.fromRGB(101, 190, 149)
	healthFill.BorderSizePixel = 0
	healthFill.Parent = healthBack

	humanoid.HealthChanged:Connect(function(health)
		healthFill.Size = UDim2.fromScale(math.clamp(health / settings.Health, 0, 1), 1)
	end)

	model.Parent = enemyFolder
	pcall(function()
		root:SetNetworkOwner(nil)
	end)

	return model, humanoid, root, settings
end

local function getNearestPlayer(position, maxDistance)
	local nearestPlayer
	local nearestRoot
	local nearestHumanoid
	local nearestDistance = maxDistance

	for _, player in ipairs(Players:GetPlayers()) do
		local character = player.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		if root and humanoid and humanoid.Health > 0 then
			local distance = (root.Position - position).Magnitude
			if distance < nearestDistance then
				nearestPlayer = player
				nearestRoot = root
				nearestHumanoid = humanoid
				nearestDistance = distance
			end
		end
	end

	return nearestPlayer, nearestRoot, nearestHumanoid, nearestDistance
end

local function damagePlayer(player, humanoid, baseDamage)
	if not player or not humanoid or humanoid.Health <= 0 then
		return
	end

	local dodgeUntil = player:GetAttribute("DodgingUntil") or 0
	if dodgeUntil > os.clock() then
		remotes.CombatFeedback:FireAllClients("dodge", player.Character.HumanoidRootPart.Position, 4, "")
		return
	end

	local damage = baseDamage
	if player:GetAttribute("Blocking") == true then
		damage = math.max(1, math.floor(baseDamage * Config.Combat.BlockDamageMultiplier))
	end

	humanoid:TakeDamage(damage)
	remotes.CombatFeedback:FireAllClients("enemy_hit", player.Character.HumanoidRootPart.Position, 5, "")
end

local function runEnemyAI(model, humanoid, root, settings, isBoss)
	local nextAttack = 0
	while model.Parent and humanoid.Health > 0 do
		local player, targetRoot, targetHumanoid, distance = getNearestPlayer(root.Position, 85)
		if player and targetRoot and targetHumanoid then
			if distance > settings.AttackRange then
				humanoid:MoveTo(targetRoot.Position)
			elseif os.clock() >= nextAttack then
				nextAttack = os.clock() + settings.AttackCooldown
				humanoid:MoveTo(root.Position)
				task.spawn(function()
					if isBoss then
						remotes.CombatFeedback:FireAllClients("boss_windup", root.Position, 17, "")
						task.wait(1.15)
						if not model.Parent or humanoid.Health <= 0 then
							return
						end
						for _, victim in ipairs(Players:GetPlayers()) do
							local character = victim.Character
							local victimRoot = character and character:FindFirstChild("HumanoidRootPart")
							local victimHumanoid = character and character:FindFirstChildOfClass("Humanoid")
							if victimRoot and victimHumanoid and (victimRoot.Position - root.Position).Magnitude <= 17 then
								damagePlayer(victim, victimHumanoid, settings.Damage)
							end
						end
						remotes.CombatFeedback:FireAllClients("boss_slam", root.Position, 17, "")
					else
					remotes.CombatFeedback:FireAllClients("enemy_windup", root.Position, 6, "")
					task.wait(0.52)
						if model.Parent and humanoid.Health > 0 and targetRoot.Parent and targetHumanoid.Health > 0 then
							if (targetRoot.Position - root.Position).Magnitude <= settings.AttackRange + 1 then
								damagePlayer(player, targetHumanoid, settings.Damage)
							end
						end
					end
				end)
			end
		else
			humanoid:MoveTo(root.Position)
		end
		task.wait(0.45)
	end
end

local function spawnOne(name, position, isBoss, respawnTime)
	local model, humanoid, root, settings = makeEnemy(name, position, isBoss)
	local rewarded = false

	humanoid.Died:Connect(function()
		if rewarded then
			return
		end
		rewarded = true

		local killerId = model:GetAttribute("LastHitBy")
		local killer = typeof(killerId) == "number" and Players:GetPlayerByUserId(killerId) or nil
		if killer then
			progressionService.AwardEnemy(killer, isBoss)
			questService.OnEnemyDefeated(killer, isBoss)
		end

		remotes.CombatFeedback:FireAllClients(isBoss and "boss_defeated" or "enemy_defeated", root.Position, isBoss and 16 or 5, "")
		task.delay(2.5, function()
			if model.Parent then
				model:Destroy()
			end
		end)

		task.delay(respawnTime, function()
			if enemyFolder.Parent then
				spawnOne(name, position, isBoss, respawnTime)
			end
		end)
	end)

	task.spawn(runEnemyAI, model, humanoid, root, settings, isBoss)
	return model
end

function NPCService.Initialize(worldData, progression, quest, remoteTable)
	progressionService = progression
	questService = quest
	remotes = remoteTable

	enemyFolder = Workspace:FindFirstChild("EclipseEnemies")
	if enemyFolder then
		enemyFolder:Destroy()
	end
	enemyFolder = Instance.new("Folder")
	enemyFolder.Name = "EclipseEnemies"
	enemyFolder.Parent = Workspace

	for index, position in ipairs(worldData.EnemySpawns) do
		spawnOne(Config.Enemies.Common.Name, position, false, Config.Enemies.Common.RespawnTime)
	end
	spawnOne(Config.Enemies.Boss.Name, worldData.BossSpawn, true, Config.Enemies.Boss.RespawnTime)
end

return NPCService
