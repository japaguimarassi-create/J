local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local ProgressionService = {}

local dataService
local remotes
local lastTraining = {}

local function xpRequired(level)
	return 100 + (level * 35)
end

local function rankForLevel(level)
	local rank = Config.Ranks[1].Name
	for _, entry in ipairs(Config.Ranks) do
		if level >= entry.Level then
			rank = entry.Name
		else
			break
		end
	end
	return rank
end

function ProgressionService.Initialize(playerDataService, remoteTable)
	dataService = playerDataService
	remotes = remoteTable
end

function ProgressionService.Sync(player)
	local profile = dataService.GetProfile(player)
	if not profile then
		return
	end

	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local health = humanoid and humanoid.Health or 100
	local maxHealth = humanoid and humanoid.MaxHealth or 100
	local energy = player:GetAttribute("Energy") or Config.MaxEnergy

	remotes.StateUpdate:FireClient(player, {
		Level = profile.Level,
		XP = profile.XP,
		XPToNext = xpRequired(profile.Level),
		Gold = profile.Gold,
		Faction = profile.Faction,
		FactionName = profile.Faction and Config.Factions[profile.Faction].DisplayName or "Sem caminho",
		StyleName = profile.Faction and Config.Factions[profile.Faction].StyleName or "—",
		Rank = rankForLevel(profile.Level),
		Mastery = profile.Faction and profile.StyleMastery[profile.Faction] or 0,
		Health = health,
		MaxHealth = maxHealth,
		Energy = energy,
		MaxEnergy = Config.MaxEnergy,
		Quest = {
			Active = profile.Quest.Active,
			Progress = profile.Quest.Progress,
			Goal = Config.QuestGoal,
			Completed = profile.Quest.Completed,
		},
		DataPersistent = player:GetAttribute("DataPersistent") == true,
	})
end

function ProgressionService.SetFaction(player, faction)
	if faction ~= "Guardiao" and faction ~= "Criatura" then
		return false
	end

	local profile = dataService.GetProfile(player)
	if not profile or profile.Faction ~= nil then
		return false
	end

	profile.Faction = faction
	dataService.MarkDirty(player)
	ProgressionService.Sync(player)
	remotes.WorldMessage:FireClient(player, "Caminho escolhido: " .. Config.Factions[faction].DisplayName)
	return true
end

function ProgressionService.Award(player, xp, gold, mastery)
	local profile = dataService.GetProfile(player)
	if not profile then
		return
	end

	profile.XP += math.max(0, math.floor(xp or 0))
	profile.Gold += math.max(0, math.floor(gold or 0))

	if profile.Faction and mastery and mastery > 0 then
		profile.StyleMastery[profile.Faction] += math.floor(mastery)
	end

	local leveledUp = false
	while profile.XP >= xpRequired(profile.Level) do
		profile.XP -= xpRequired(profile.Level)
		profile.Level += 1
		leveledUp = true
	end

	dataService.MarkDirty(player)
	ProgressionService.Sync(player)

	if leveledUp then
		remotes.WorldMessage:FireClient(player, "NÍVEL " .. profile.Level .. " ALCANÇADO")
	end
end

function ProgressionService.AwardEnemy(player, isBoss)
	if isBoss then
		ProgressionService.Award(player, Config.Enemies.Boss.XP, Config.Enemies.Boss.Gold, 10)
	else
		ProgressionService.Award(player, Config.Enemies.Common.XP, Config.Enemies.Common.Gold, 2)
	end
end

function ProgressionService.Train(player)
	local profile = dataService.GetProfile(player)
	if not profile or not profile.Faction then
		return
	end

	local now = os.clock()
	local previous = lastTraining[player.UserId] or 0
	if now - previous < Config.TrainingCooldown then
		remotes.WorldMessage:FireClient(player, "Respire. O próximo ciclo de treino ainda não está disponível.")
		return
	end

	lastTraining[player.UserId] = now
	profile.StyleMastery[profile.Faction] += 4
	player:SetAttribute("Energy", math.min(Config.MaxEnergy, (player:GetAttribute("Energy") or 0) + 18))
	ProgressionService.Award(player, 8, 0, 0)
	remotes.WorldMessage:FireClient(player, "+4 domínio · +8 XP · energia recuperada")
end

function ProgressionService.Cleanup(player)
	lastTraining[player.UserId] = nil
end

return ProgressionService
