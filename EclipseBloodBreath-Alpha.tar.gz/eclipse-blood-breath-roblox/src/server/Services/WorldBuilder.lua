local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local WorldBuilder = {}

local function makePart(parent, name, size, cframe, color, material, anchored, transparency)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = anchored ~= false
	part.Transparency = transparency or 0
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
	return part
end

local function makeSign(parent, text, position, width)
	local board = makePart(parent, "Signboard", Vector3.new(width or 15, 5, 0.6), CFrame.new(position) * CFrame.Angles(0, math.rad(180), 0), Color3.fromRGB(35, 32, 42), Enum.Material.WoodPlanks)
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = 35
	gui.Parent = board

	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Text = text
	label.TextColor3 = Color3.fromRGB(242, 222, 185)
	label.TextScaled = true
	label.Font = Enum.Font.GothamBold
	label.Parent = gui
	return board
end

local function makeLantern(parent, position)
	local post = makePart(parent, "LanternPost", Vector3.new(0.6, 7, 0.6), CFrame.new(position + Vector3.new(0, 3.5, 0)), Color3.fromRGB(76, 49, 43), Enum.Material.Wood)
	local lamp = makePart(parent, "LanternGlow", Vector3.new(2.2, 2.8, 2.2), CFrame.new(position + Vector3.new(0, 6.5, 0)), Color3.fromRGB(255, 171, 91), Enum.Material.Neon)
	lamp.Shape = Enum.PartType.Ball
	lamp.Transparency = 0.12
	local light = Instance.new("PointLight")
	light.Color = Color3.fromRGB(255, 174, 107)
	light.Brightness = 1.6
	light.Range = 20
	light.Shadows = false
	light.Parent = lamp
	return post
end

local function makeHouse(parent, name, center, scale)
	local s = scale or 1
	local base = Vector3.new(18, 9, 15) * s
	makePart(parent, name .. "_Walls", base, CFrame.new(center + Vector3.new(0, 4.5 * s, 0)), Color3.fromRGB(97, 68, 57), Enum.Material.WoodPlanks)
	makePart(parent, name .. "_Roof", Vector3.new(23, 2, 20) * s, CFrame.new(center + Vector3.new(0, 10 * s, 0)), Color3.fromRGB(43, 48, 61), Enum.Material.Slate)
	makePart(parent, name .. "_RoofRidge", Vector3.new(23, 1, 2) * s, CFrame.new(center + Vector3.new(0, 11.2 * s, 0)), Color3.fromRGB(31, 36, 49), Enum.Material.Slate)
	makePart(parent, name .. "_Door", Vector3.new(3, 6, 0.5) * s, CFrame.new(center + Vector3.new(0, 3 * s, -7.7 * s)), Color3.fromRGB(47, 34, 31), Enum.Material.Wood)
	makePart(parent, name .. "_Step", Vector3.new(6, 0.7, 2) * s, CFrame.new(center + Vector3.new(0, 0.35 * s, -9 * s)), Color3.fromRGB(106, 100, 99), Enum.Material.Cobblestone)
end

local function makeTree(parent, position, height, seed)
	local rng = Random.new(seed)
	local trunkHeight = height * 0.55
	local trunk = makePart(parent, "ForestTrunk", Vector3.new(trunkHeight, 2.4, 2.4), CFrame.new(position + Vector3.new(0, trunkHeight / 2, 0)), Color3.fromRGB(79, 58, 49), Enum.Material.Wood)
	trunk.Shape = Enum.PartType.Cylinder
	trunk.Orientation = Vector3.new(0, 0, 90)
	local canopyColor = Color3.fromRGB(45 + rng:NextInteger(0, 18), 78 + rng:NextInteger(0, 25), 72 + rng:NextInteger(0, 18))
	local canopy = makePart(parent, "ForestCanopy", Vector3.new(height * 0.72, height * 0.58, height * 0.72), CFrame.new(position + Vector3.new(0, trunkHeight + height * 0.18, 0)), canopyColor, Enum.Material.Grass)
	canopy.Shape = Enum.PartType.Ball
end

local function makePillar(parent, position, height, color)
	local shaft = makePart(parent, "ArenaPillar", Vector3.new(4, height, 4), CFrame.new(position + Vector3.new(0, height / 2, 0)), color, Enum.Material.Slate)
	local cap = makePart(parent, "ArenaPillarCap", Vector3.new(6, 1.2, 6), CFrame.new(position + Vector3.new(0, height + 0.6, 0)), Color3.fromRGB(67, 62, 78), Enum.Material.Slate)
	return shaft, cap
end

function WorldBuilder.Build()
	local old = Workspace:FindFirstChild("EclipseWorld")
	if old then
		old:Destroy()
	end

	local world = Instance.new("Folder")
	world.Name = "EclipseWorld"
	world.Parent = Workspace

	local geometry = Instance.new("Folder")
	geometry.Name = "Geometry"
	geometry.Parent = world

	local spawns = Instance.new("Folder")
	spawns.Name = "PlayerAndEnemySpawns"
	spawns.Parent = world

	Lighting.ClockTime = 18.35
	Lighting.Brightness = 2
	Lighting.Ambient = Color3.fromRGB(83, 91, 126)
	Lighting.OutdoorAmbient = Color3.fromRGB(104, 111, 145)
	Lighting.FogColor = Color3.fromRGB(40, 47, 74)
	Lighting.FogStart = 120
	Lighting.FogEnd = 620

	local atmosphere = Lighting:FindFirstChildOfClass("Atmosphere") or Instance.new("Atmosphere")
	atmosphere.Density = 0.24
	atmosphere.Offset = 0.1
	atmosphere.Color = Color3.fromRGB(154, 169, 202)
	atmosphere.Decay = Color3.fromRGB(66, 58, 92)
	atmosphere.Glare = 0.18
	atmosphere.Haze = 1.2
	atmosphere.Parent = Lighting

	local colorCorrection = Lighting:FindFirstChild("EclipseColorCorrection") or Instance.new("ColorCorrectionEffect")
	colorCorrection.Name = "EclipseColorCorrection"
	colorCorrection.TintColor = Color3.fromRGB(211, 218, 255)
	colorCorrection.Contrast = 0.08
	colorCorrection.Saturation = -0.12
	colorCorrection.Parent = Lighting

	makePart(geometry, "WorldGround", Vector3.new(620, 4, 620), CFrame.new(0, -2, 0), Color3.fromRGB(57, 77, 65), Enum.Material.Grass)
	makePart(geometry, "VillagePlaza", Vector3.new(132, 1, 112), CFrame.new(0, 0.1, 0), Color3.fromRGB(113, 111, 113), Enum.Material.Cobblestone)
	makePart(geometry, "ForestRoad", Vector3.new(22, 0.45, 170), CFrame.new(0, 0.45, 136), Color3.fromRGB(103, 94, 86), Enum.Material.Ground)
	makePart(geometry, "ForestBridge", Vector3.new(24, 1, 22), CFrame.new(0, 0.8, 108), Color3.fromRGB(97, 68, 54), Enum.Material.WoodPlanks)
	makePart(geometry, "BossApproach", Vector3.new(22, 0.5, 80), CFrame.new(112, 0.5, 190) * CFrame.Angles(0, math.rad(-48), 0), Color3.fromRGB(91, 83, 91), Enum.Material.Slate)

	makeHouse(geometry, "Dojo", Vector3.new(-48, 0, -23), 1.25)
	makeHouse(geometry, "MarketHall", Vector3.new(46, 0, -28), 0.95)
	makeHouse(geometry, "WayfarerHouse", Vector3.new(45, 0, 31), 0.78)
	makeSign(geometry, "VILA DO PRIMEIRO JURAMENTO", Vector3.new(0, 8, -55), 27)
	makeSign(geometry, "BOSQUE DOS SINOS  →", Vector3.new(0, 7, 71), 18)
	makeSign(geometry, "ARENA DA FENDA  →", Vector3.new(112, 7, 180), 18)

	for _, x in ipairs({ -53, -28, 28, 53 }) do
		makeLantern(geometry, Vector3.new(x, 0, -2))
	end
	for _, z in ipairs({ 18, 48, 78, 108, 138 }) do
		makeLantern(geometry, Vector3.new(-14, 0, z))
		makeLantern(geometry, Vector3.new(14, 0, z))
	end

	local gateCenter = Vector3.new(0, 0, 61)
	makePart(geometry, "GateLeftPost", Vector3.new(3, 18, 3), CFrame.new(gateCenter + Vector3.new(-12, 9, 0)), Color3.fromRGB(118, 61, 54), Enum.Material.Wood)
	makePart(geometry, "GateRightPost", Vector3.new(3, 18, 3), CFrame.new(gateCenter + Vector3.new(12, 9, 0)), Color3.fromRGB(118, 61, 54), Enum.Material.Wood)
	makePart(geometry, "GateCrossbeam", Vector3.new(31, 3, 4), CFrame.new(gateCenter + Vector3.new(0, 17, 0)), Color3.fromRGB(137, 70, 58), Enum.Material.Wood)
	makePart(geometry, "GateUpperBeam", Vector3.new(35, 2, 5), CFrame.new(gateCenter + Vector3.new(0, 20, 0)), Color3.fromRGB(59, 47, 61), Enum.Material.Slate)

	local training = Instance.new("Folder")
	training.Name = "TrainingYard"
	training.Parent = geometry
	makePart(training, "TrainingFloor", Vector3.new(72, 0.6, 54), CFrame.new(-82, 0.55, 32), Color3.fromRGB(107, 89, 74), Enum.Material.Ground)
	for index = 1, 4 do
		local x = -105 + (index * 15)
		local post = makePart(training, "PracticePost", Vector3.new(1.2, 8, 1.2), CFrame.new(x, 4.5, 15), Color3.fromRGB(94, 64, 48), Enum.Material.Wood)
		makePart(training, "PracticeTarget", Vector3.new(4, 3, 1.3), CFrame.new(x, 7, 15), Color3.fromRGB(175, 133, 97), Enum.Material.Fabric)
		post.CanCollide = true
	end
	makeSign(training, "PÁTIO DE TREINO · T / TREINO", Vector3.new(-82, 8, 5), 20)

	local forest = Instance.new("Folder")
	forest.Name = "BellForest"
	forest.Parent = geometry
	math.randomseed(4172)
	local treeSeed = 0
	for row = 1, 7 do
		for column = 1, 8 do
			local x = -78 + (column * 22) + math.random(-5, 5)
			local z = 135 + (row * 20) + math.random(-6, 6)
			if math.abs(x) > 17 then
				treeSeed += 1
				makeTree(forest, Vector3.new(x, 0, z), math.random(23, 34), treeSeed)
			end
		end
	end
	for index = 1, 16 do
		local x = math.random(-74, 74)
		local z = math.random(142, 270)
		if math.abs(x) > 18 then
			local rock = makePart(forest, "ForestStone", Vector3.new(math.random(4, 8), math.random(3, 7), math.random(4, 8)), CFrame.new(x, 1.5, z), Color3.fromRGB(77, 82, 91), Enum.Material.Slate)
			rock.Shape = Enum.PartType.Ball
		end
	end

	local arena = Instance.new("Folder")
	arena.Name = "RiftArena"
	arena.Parent = geometry
	local arenaCenter = Vector3.new(176, 0, 214)
	local disk = makePart(arena, "ArenaPlatform", Vector3.new(3, 96, 96), CFrame.new(arenaCenter + Vector3.new(0, 0.6, 0)), Color3.fromRGB(61, 60, 78), Enum.Material.Slate)
	disk.Shape = Enum.PartType.Cylinder
	disk.Orientation = Vector3.new(0, 0, 90)
	local innerRing = makePart(arena, "RiftRing", Vector3.new(0.55, 70, 70), CFrame.new(arenaCenter + Vector3.new(0, 2.2, 0)), Color3.fromRGB(93, 72, 108), Enum.Material.Basalt)
	innerRing.Shape = Enum.PartType.Cylinder
	innerRing.Orientation = Vector3.new(0, 0, 90)
	for _, offset in ipairs({ Vector3.new(-35, 2, -35), Vector3.new(35, 2, -35), Vector3.new(-35, 2, 35), Vector3.new(35, 2, 35) }) do
		makePillar(arena, arenaCenter + offset, 19, Color3.fromRGB(73, 59, 82))
	end
	makeSign(arena, "SENTINELA DA FENDA", arenaCenter + Vector3.new(0, 10, -52), 22)

	local playerSpawn = Instance.new("SpawnLocation")
	playerSpawn.Name = "VillageSpawn"
	playerSpawn.Size = Vector3.new(10, 1, 10)
	playerSpawn.CFrame = CFrame.new(0, 1.2, -5)
	playerSpawn.Anchored = true
	playerSpawn.Neutral = true
	playerSpawn.Duration = 0
	playerSpawn.Transparency = 1
	playerSpawn.CanCollide = true
	playerSpawn.Parent = spawns

	return {
		EnemySpawns = {
			Vector3.new(0, 3, 160),
			Vector3.new(-12, 3, 190),
			Vector3.new(12, 3, 218),
			Vector3.new(-10, 3, 245),
			Vector3.new(9, 3, 272),
		},
		BossSpawn = arenaCenter + Vector3.new(0, 5, 0),
	}
end

return WorldBuilder
