local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))

local QuestService = {}
local dataService
local progressionService
local remotes

function QuestService.Initialize(playerDataService, progression, remoteTable)
	dataService = playerDataService
	progressionService = progression
	remotes = remoteTable
end

function QuestService.AcceptTrial(player)
	local profile = dataService.GetProfile(player)
	if not profile or not profile.Faction then
		remotes.WorldMessage:FireClient(player, "Escolha um caminho antes de aceitar a prova.")
		return
	end

	if profile.Quest.Completed then
		remotes.WorldMessage:FireClient(player, "A Primeira Prova já foi concluída.")
		return
	end

	if profile.Quest.Active then
		remotes.WorldMessage:FireClient(player, "Prova em andamento: derrote três Sombras Errantes.")
		return
	end

	profile.Quest.Active = true
	profile.Quest.Progress = 0
	dataService.MarkDirty(player)
	progressionService.Sync(player)
	remotes.WorldMessage:FireClient(player, "PRIMEIRA PROVA: derrote 3 Sombras Errantes no Bosque dos Sinos.")
end

function QuestService.OnEnemyDefeated(player, isBoss)
	if not player then
		return
	end

	local profile = dataService.GetProfile(player)
	if not profile or not profile.Quest.Active or profile.Quest.Completed or isBoss then
		return
	end

	profile.Quest.Progress = math.min(Config.QuestGoal, profile.Quest.Progress + 1)
	if profile.Quest.Progress >= Config.QuestGoal then
		profile.Quest.Active = false
		profile.Quest.Completed = true
		dataService.MarkDirty(player)
		progressionService.Award(player, 140, 65, 12)
		remotes.WorldMessage:FireClient(player, "PROVA CONCLUÍDA · +140 XP · +65 moedas · +12 domínio")
	else
		dataService.MarkDirty(player)
		remotes.WorldMessage:FireClient(player, "Progresso da prova: " .. profile.Quest.Progress .. "/" .. Config.QuestGoal)
	end

	progressionService.Sync(player)
end

return QuestService
