local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local Store = DataStoreService:GetDataStore(Config.DataStoreName)

local PlayerDataService = {}
local profiles = {}
local initialized = false

local function deepCopy(value)
	if type(value) ~= "table" then
		return value
	end

	local copy = {}
	for key, child in pairs(value) do
		copy[key] = deepCopy(child)
	end
	return copy
end

local function defaultProfile()
	return {
		Version = Config.ProfileVersion,
		Level = 1,
		XP = 0,
		Faction = nil,
		Gold = 0,
		StyleMastery = {
			Guardiao = 0,
			Criatura = 0,
		},
		Quest = {
			Active = false,
			Progress = 0,
			Completed = false,
		},
		Settings = {
			CameraShake = true,
			ReducedEffects = false,
		},
	}
end

local function migrate(raw)
	local profile = defaultProfile()
	if type(raw) ~= "table" then
		return profile
	end

	profile.Level = math.max(1, tonumber(raw.Level) or 1)
	profile.XP = math.max(0, tonumber(raw.XP) or 0)
	profile.Gold = math.max(0, tonumber(raw.Gold) or 0)

	if raw.Faction == "Guardiao" or raw.Faction == "Criatura" then
		profile.Faction = raw.Faction
	end

	if type(raw.StyleMastery) == "table" then
		profile.StyleMastery.Guardiao = math.max(0, tonumber(raw.StyleMastery.Guardiao) or 0)
		profile.StyleMastery.Criatura = math.max(0, tonumber(raw.StyleMastery.Criatura) or 0)
	end

	if type(raw.Quest) == "table" then
		profile.Quest.Active = raw.Quest.Active == true
		profile.Quest.Progress = math.clamp(math.floor(tonumber(raw.Quest.Progress) or 0), 0, Config.QuestGoal)
		profile.Quest.Completed = raw.Quest.Completed == true
	end

	if type(raw.Settings) == "table" then
		profile.Settings.CameraShake = raw.Settings.CameraShake ~= false
		profile.Settings.ReducedEffects = raw.Settings.ReducedEffects == true
	end

	profile.Version = Config.ProfileVersion
	return profile
end

function PlayerDataService.Initialize()
	if initialized then
		return
	end
	initialized = true

	Players.PlayerRemoving:Connect(function(player)
		PlayerDataService.Save(player)
		profiles[player.UserId] = nil
	end)

	game:BindToClose(function()
		for _, player in ipairs(Players:GetPlayers()) do
			PlayerDataService.Save(player)
			 task.wait(0.1)
		end
	end)
end

function PlayerDataService.Load(player)
	local key = tostring(player.UserId)
	local ok, raw = pcall(function()
		return Store:GetAsync(key)
	end)

	if not player.Parent then
		return nil
	end

	local profile
	local canSave = ok
	if ok then
		profile = migrate(raw)
	else
		profile = defaultProfile()
		warn("[PlayerDataService] Profile read failed for " .. player.UserId .. "; persistence disabled for this session: " .. tostring(raw))
	end

	profiles[player.UserId] = {
		Data = profile,
		CanSave = canSave,
		Dirty = false,
	}

	player:SetAttribute("DataLoaded", true)
	player:SetAttribute("DataPersistent", canSave)
	return profile
end

function PlayerDataService.GetProfile(player)
	local record = profiles[player.UserId]
	return record and record.Data or nil
end

function PlayerDataService.MarkDirty(player)
	local record = profiles[player.UserId]
	if record then
		record.Dirty = true
	end
end

function PlayerDataService.Save(player)
	local record = profiles[player.UserId]
	if not record or not record.CanSave or not record.Dirty then
		return record ~= nil
	end

	local snapshot = deepCopy(record.Data)
	local key = tostring(player.UserId)
	local ok, result = pcall(function()
		return Store:UpdateAsync(key, function()
			return snapshot
		end)
	end)

	if ok then
		record.Dirty = false
		return true
	end

	warn("[PlayerDataService] Save failed for " .. player.UserId .. ": " .. tostring(result))
	return false
end

task.spawn(function()
	while true do
		task.wait(90)
		for _, player in ipairs(Players:GetPlayers()) do
			PlayerDataService.Save(player)
		end
	end
end)

return PlayerDataService
