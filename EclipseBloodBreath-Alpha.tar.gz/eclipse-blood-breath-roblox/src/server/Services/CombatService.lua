local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local CombatService = {}

local dataService
local progressionService
local remotes
local cooldowns = {}

local function getCooldownTable(player)
	cooldowns[player.UserId] = cooldowns[player.UserId] or {}
	return cooldowns[player.UserId]
end

local function ready(player, action, cooldown)
	local tableForPlayer = getCooldownTable(player)
	local now = os.clock()
	if now - (tableForPlayer[action] or 0) < cooldown then
		return false
	end
	tableForPlayer[action] = now
	return true
end

local function characterReady(player)
	if player:GetAttribute("DataLoaded") ~= true then
		return nil, nil, nil
	end
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not character or not humanoid or not root or humanoid.Health <= 0 then
		return nil, nil, nil
	end
	return character, humanoid, root
end

local function findEnemyModels(parts)
	local result = {}
	local seen = {}
	for _, part in ipairs(parts) do
		local model = part:FindFirstAncestorOfClass("Model")
		if model and model:GetAttribute("IsEnemy") == true and not seen[model] then
			seen[model] = true
			table.insert(result, model)
		end
	end
	return result
end

local function dealHit(player, targetModel, damage, faction)
	local targetHumanoid = targetModel:FindFirstChildOfClass("Humanoid")
	local targetRoot = targetModel:FindFirstChild("HumanoidRootPart")
	if not targetHumanoid or not targetRoot or targetHumanoid.Health <= 0 then
		return false
	end

	targetModel:SetAttribute("LastHitBy", player.UserId)
	targetHumanoid:TakeDamage(damage)
	remotes.CombatFeedback:FireAllClients("hit", targetRoot.Position, 4, faction or "")
	return true
end

local function performHitbox(player, action, settings)
	local character, _, root = characterReady(player)
	if not character or player:GetAttribute("Blocking") == true then
		return
	end

	local profile = dataService.GetProfile(player)
	if not profile or not profile.Faction then
		return
	end

	local params = OverlapParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { character }
	params.MaxParts = 80

	local center = root.CFrame * CFrame.new(0, 0, -(settings.Range / 2 + 1))
	local boxSize = Vector3.new(settings.Width or 7, settings.Height or 6, settings.Range + 2)
	local targets = findEnemyModels(Workspace:GetPartBoundsInBox(center, boxSize, params))
	local hit = false

	for _, target in ipairs(targets) do
		local targetRoot = target:FindFirstChild("HumanoidRootPart")
		if targetRoot and (targetRoot.Position - root.Position).Magnitude <= settings.Range + 3 then
			hit = dealHit(player, target, settings.Damage, profile.Faction) or hit
		end
	end

	remotes.CombatFeedback:FireClient(player, hit and "attack_confirm" or "attack_swing", root.Position, settings.Range, profile.Faction)
end

local function performSkill(player, settings)
	local character, _, root = characterReady(player)
	if not character then
		return
	end
	local profile = dataService.GetProfile(player)
	if not profile or not profile.Faction then
		return
	end

	local params = OverlapParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { character }
	params.MaxParts = 100

	local targets = {}
	if profile.Faction == "Guardiao" then
		local center = root.CFrame * CFrame.new(0, 0, -7)
		targets = findEnemyModels(Workspace:GetPartBoundsInBox(center, Vector3.new(15, 7, 18), params))
	else
		targets = findEnemyModels(Workspace:GetPartBoundsInRadius(root.Position, settings.Radius, params))
	end

	for _, target in ipairs(targets) do
		local targetRoot = target:FindFirstChild("HumanoidRootPart")
		if targetRoot and (targetRoot.Position - root.Position).Magnitude <= settings.Range + 4 then
			dealHit(player, target, settings.Damage, profile.Faction)
		end
	end

	remotes.CombatFeedback:FireAllClients(profile.Faction == "Guardiao" and "tide_skill" or "abyss_skill", root.Position, settings.Radius, profile.Faction)
end

local function startAttack(player, action)
	local settings = Config.Combat[action]
	if not settings or not ready(player, action, settings.Cooldown) then
		return
	end

	local character, humanoid = characterReady(player)
	local profile = dataService.GetProfile(player)
	if not character or not profile or not profile.Faction or player:GetAttribute("CombatLocked") == true or player:GetAttribute("Blocking") == true then
		return
	end

	player:SetAttribute("CombatLocked", true)
	remotes.CombatFeedback:FireAllClients("attack_windup", character:GetPivot().Position, settings.Range, profile.Faction)

	task.delay(settings.Startup, function()
		if player.Parent then
			performHitbox(player, action, settings)
		end
	end)

	task.delay(settings.Startup + settings.Recovery, function()
		if player.Parent then
			player:SetAttribute("CombatLocked", false)
		end
	end)
end

local function startSkill(player)
	local settings = Config.Combat.Skill
	if not ready(player, "Skill", settings.Cooldown) then
		return
	end
	local character = characterReady(player)
	local profile = dataService.GetProfile(player)
	if not character or not profile or not profile.Faction or player:GetAttribute("CombatLocked") == true or player:GetAttribute("Blocking") == true then
		return
	end

	local energy = player:GetAttribute("Energy") or Config.MaxEnergy
	if energy < settings.EnergyCost then
		remotes.WorldMessage:FireClient(player, "Energia insuficiente para a técnica.")
		return
	end

	player:SetAttribute("Energy", energy - settings.EnergyCost)
	player:SetAttribute("CombatLocked", true)
	remotes.CombatFeedback:FireAllClients("skill_windup", character:GetPivot().Position, settings.Radius, profile.Faction)

	task.delay(settings.Startup, function()
		if player.Parent then
			performSkill(player, settings)
		end
	end)

	task.delay(settings.Startup + settings.Recovery, function()
		if player.Parent then
			player:SetAttribute("CombatLocked", false)
			progressionService.Sync(player)
		end
	end)
end

local function dodge(player)
	local settings = Config.Combat.Dodge
	if not ready(player, "Dodge", settings.Cooldown) then
		return
	end
	local character, _, root = characterReady(player)
	if not character or player:GetAttribute("CombatLocked") == true then
		return
	end

	local energy = player:GetAttribute("Energy") or Config.MaxEnergy
	if energy < settings.EnergyCost then
		return
	end
	player:SetAttribute("Energy", energy - settings.EnergyCost)
	player:SetAttribute("DodgingUntil", os.clock() + settings.Duration)

	local direction = root.CFrame.LookVector
	local moveDirection = character:FindFirstChildOfClass("Humanoid").MoveDirection
	if moveDirection.Magnitude > 0.1 then
		direction = moveDirection.Unit
	end
	root.AssemblyLinearVelocity = Vector3.new(direction.X * settings.Speed, math.max(root.AssemblyLinearVelocity.Y, 3), direction.Z * settings.Speed)
	remotes.CombatFeedback:FireAllClients("dash", root.Position, 5, "")
	progressionService.Sync(player)
end

function CombatService.Initialize(playerDataService, progression, remoteTable)
	dataService = playerDataService
	progressionService = progression
	remotes = remoteTable

	remotes.CombatRequest.OnServerEvent:Connect(function(player, action)
		if typeof(action) ~= "string" or #action > 20 then
			return
		end
		if action == "Light" or action == "Heavy" then
			startAttack(player, action)
		elseif action == "Skill" then
			startSkill(player)
		elseif action == "Dodge" then
			dodge(player)
		elseif action == "BlockStart" then
			local character = characterReady(player)
			local profile = dataService.GetProfile(player)
			if character and profile and profile.Faction and player:GetAttribute("CombatLocked") ~= true then
				player:SetAttribute("Blocking", true)
			end
		elseif action == "BlockEnd" then
			player:SetAttribute("Blocking", false)
		end
	end)

	Players.PlayerRemoving:Connect(function(player)
		cooldowns[player.UserId] = nil
	end)

	task.spawn(function()
		while true do
			task.wait(0.8)
			for _, player in ipairs(Players:GetPlayers()) do
				if player:GetAttribute("DataLoaded") == true then
					local current = player:GetAttribute("Energy") or 0
					local nextValue = math.min(Config.MaxEnergy, current + Config.EnergyRegenPerSecond * 0.8)
					if nextValue ~= current then
						player:SetAttribute("Energy", nextValue)
						progressionService.Sync(player)
					end
				end
			end
		end
	end)
end

return CombatService
