local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local Services = script:WaitForChild("Services")

local RemoteService = require(Services:WaitForChild("RemoteService"))
local PlayerDataService = require(Services:WaitForChild("PlayerDataService"))
local ProgressionService = require(Services:WaitForChild("ProgressionService"))
local QuestService = require(Services:WaitForChild("QuestService"))
local WorldBuilder = require(Services:WaitForChild("WorldBuilder"))
local NPCService = require(Services:WaitForChild("NPCService"))
local CombatService = require(Services:WaitForChild("CombatService"))

local remotes = RemoteService.Initialize()
PlayerDataService.Initialize()
ProgressionService.Initialize(PlayerDataService, remotes)
QuestService.Initialize(PlayerDataService, ProgressionService, remotes)

local worldData = WorldBuilder.Build()
NPCService.Initialize(worldData, ProgressionService, QuestService, remotes)
CombatService.Initialize(PlayerDataService, ProgressionService, remotes)

local function setupPlayer(player)
	player:SetAttribute("DataLoaded", false)
	player:SetAttribute("DataPersistent", false)
	player:SetAttribute("Energy", Config.MaxEnergy)
	player:SetAttribute("Blocking", false)
	player:SetAttribute("CombatLocked", false)
	player:SetAttribute("DodgingUntil", 0)

	player.CharacterAdded:Connect(function(character)
		player:SetAttribute("Energy", Config.MaxEnergy)
		player:SetAttribute("Blocking", false)
		player:SetAttribute("CombatLocked", false)
		player:SetAttribute("DodgingUntil", 0)
		task.spawn(function()
			local humanoid = character:WaitForChild("Humanoid", 10)
			if humanoid and player.Parent then
				task.wait(0.25)
				ProgressionService.Sync(player)
			end
		end)
	end)

	task.spawn(function()
		PlayerDataService.Load(player)
		if player.Parent then
			ProgressionService.Sync(player)
			if player:GetAttribute("DataPersistent") ~= true then
				remotes.WorldMessage:FireClient(player, "Aviso: esta sessão está em modo temporário; o progresso pode não ser salvo.")
			end
		end
	end)
end

Players.PlayerAdded:Connect(setupPlayer)
for _, player in ipairs(Players:GetPlayers()) do
	setupPlayer(player)
end

remotes.FactionRequest.OnServerEvent:Connect(function(player, faction)
	if typeof(faction) ~= "string" or #faction > 20 then
		return
	end
	ProgressionService.SetFaction(player, faction)
end)

remotes.QuestRequest.OnServerEvent:Connect(function(player, action)
	if action == "AcceptTrial" then
		QuestService.AcceptTrial(player)
	end
end)

remotes.TrainRequest.OnServerEvent:Connect(function(player)
	ProgressionService.Train(player)
end)

Players.PlayerRemoving:Connect(function(player)
	ProgressionService.Cleanup(player)
end)

print("[Eclipse] Vertical slice initialized. World, combat, NPCs and player services are online.")
