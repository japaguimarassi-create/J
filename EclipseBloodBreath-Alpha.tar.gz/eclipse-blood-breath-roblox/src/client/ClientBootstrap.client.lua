local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local ContextActionService = game:GetService("ContextActionService")
local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local CombatRequest = Remotes:WaitForChild("CombatRequest")
local FactionRequest = Remotes:WaitForChild("FactionRequest")
local TrainRequest = Remotes:WaitForChild("TrainRequest")
local QuestRequest = Remotes:WaitForChild("QuestRequest")
local StateUpdate = Remotes:WaitForChild("StateUpdate")
local CombatFeedback = Remotes:WaitForChild("CombatFeedback")
local WorldMessage = Remotes:WaitForChild("WorldMessage")

local palette = {
	Panel = Color3.fromRGB(18, 20, 31),
	PanelLight = Color3.fromRGB(31, 35, 51),
	Text = Color3.fromRGB(241, 238, 230),
	Muted = Color3.fromRGB(165, 171, 190),
	Blue = Color3.fromRGB(83, 173, 232),
	Red = Color3.fromRGB(198, 73, 112),
	Gold = Color3.fromRGB(222, 175, 102),
	Green = Color3.fromRGB(91, 186, 147),
}

local function make(className, properties, parent)
	local instance = Instance.new(className)
	for key, value in pairs(properties or {}) do
		instance[key] = value
	end
	instance.Parent = parent
	return instance
end

local function round(instance, radius)
	make("UICorner", { CornerRadius = UDim.new(0, radius or 12) }, instance)
end

local function stroke(instance, color, transparency, thickness)
	make("UIStroke", {
		Color = color or Color3.fromRGB(88, 102, 137),
		Transparency = transparency or 0.55,
		Thickness = thickness or 1,
	}, instance)
end

local gui = make("ScreenGui", {
	Name = "EclipseHUD",
	ResetOnSpawn = false,
	IgnoreGuiInset = true,
	DisplayOrder = 20,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, playerGui)

local topPanel = make("Frame", {
	Name = "StatusPanel",
	AnchorPoint = Vector2.new(0, 0),
	Position = UDim2.fromOffset(18, 18),
	Size = UDim2.fromOffset(292, 142),
	BackgroundColor3 = palette.Panel,
	BackgroundTransparency = 0.12,
	BorderSizePixel = 0,
}, gui)
round(topPanel, 14)
stroke(topPanel, palette.Blue, 0.7, 1)

local title = make("TextLabel", {
	Name = "GameTitle",
	Position = UDim2.fromOffset(14, 8),
	Size = UDim2.new(1, -28, 0, 24),
	BackgroundTransparency = 1,
	Text = "ECLIPSE  /  BLOOD & BREATH",
	TextColor3 = palette.Gold,
	TextXAlignment = Enum.TextXAlignment.Left,
	Font = Enum.Font.GothamBold,
	TextSize = 13,
}, topPanel)

local identity = make("TextLabel", {
	Name = "Identity",
	Position = UDim2.fromOffset(14, 33),
	Size = UDim2.new(1, -28, 0, 22),
	BackgroundTransparency = 1,
	Text = "Nível 1  ·  Sem caminho",
	TextColor3 = palette.Text,
	TextXAlignment = Enum.TextXAlignment.Left,
	Font = Enum.Font.GothamSemibold,
	TextSize = 13,
}, topPanel)

local rankLabel = make("TextLabel", {
	Name = "Rank",
	Position = UDim2.fromOffset(14, 55),
	Size = UDim2.new(1, -28, 0, 18),
	BackgroundTransparency = 1,
	Text = "Recruta  ·  Domínio 0",
	TextColor3 = palette.Muted,
	TextXAlignment = Enum.TextXAlignment.Left,
	Font = Enum.Font.Gotham,
	TextSize = 11,
}, topPanel)

local function makeBar(parent, name, y, color, prefix)
	make("TextLabel", {
		Name = name .. "Label",
		Position = UDim2.fromOffset(14, y),
		Size = UDim2.fromOffset(54, 14),
		BackgroundTransparency = 1,
		Text = prefix,
		TextColor3 = palette.Muted,
		TextXAlignment = Enum.TextXAlignment.Left,
		Font = Enum.Font.GothamBold,
		TextSize = 10,
	}, parent)
	local back = make("Frame", {
		Name = name .. "Back",
		Position = UDim2.fromOffset(67, y + 1),
		Size = UDim2.new(1, -81, 0, 10),
		BackgroundColor3 = Color3.fromRGB(48, 49, 65),
		BorderSizePixel = 0,
	}, parent)
	round(back, 6)
	local fill = make("Frame", {
		Name = name .. "Fill",
		Size = UDim2.fromScale(1, 1),
		BackgroundColor3 = color,
		BorderSizePixel = 0,
	}, back)
	round(fill, 6)
	return fill
end

local healthFill = makeBar(topPanel, "Health", 82, palette.Red, "VIDA")
local energyFill = makeBar(topPanel, "Energy", 101, palette.Blue, "ENERGIA")
local xpFill = makeBar(topPanel, "XP", 120, palette.Gold, "XP")

local saveLabel = make("TextLabel", {
	Name = "SaveStatus",
	AnchorPoint = Vector2.new(0, 0),
	Position = UDim2.fromOffset(18, 164),
	Size = UDim2.fromOffset(292, 17),
	BackgroundTransparency = 1,
	Text = "Carregando perfil...",
	TextColor3 = palette.Muted,
	TextXAlignment = Enum.TextXAlignment.Left,
	Font = Enum.Font.Gotham,
	TextSize = 10,
}, gui)

local questPanel = make("Frame", {
	Name = "QuestPanel",
	AnchorPoint = UserInputService.TouchEnabled and Vector2.new(0, 0) or Vector2.new(0, 1),
	Position = UserInputService.TouchEnabled and UDim2.fromOffset(18, 194) or UDim2.new(0, 18, 1, -22),
	Size = UDim2.fromOffset(310, 76),
	BackgroundColor3 = palette.Panel,
	BackgroundTransparency = 0.14,
	BorderSizePixel = 0,
}, gui)
round(questPanel, 12)
stroke(questPanel, palette.Gold, 0.75, 1)

local questTitle = make("TextLabel", {
	Name = "QuestTitle",
	Position = UDim2.fromOffset(12, 8),
	Size = UDim2.new(1, -24, 0, 20),
	BackgroundTransparency = 1,
	Text = "PRIMEIRA PROVA",
	TextColor3 = palette.Gold,
	TextXAlignment = Enum.TextXAlignment.Left,
	Font = Enum.Font.GothamBold,
	TextSize = 11,
}, questPanel)

local questText = make("TextLabel", {
	Name = "QuestText",
	Position = UDim2.fromOffset(12, 29),
	Size = UDim2.new(1, -24, 0, 34),
	BackgroundTransparency = 1,
	Text = "Aceite a prova e derrote 3 Sombras Errantes.",
	TextColor3 = palette.Text,
	TextWrapped = true,
	TextXAlignment = Enum.TextXAlignment.Left,
	TextYAlignment = Enum.TextYAlignment.Top,
	Font = Enum.Font.Gotham,
	TextSize = 11,
}, questPanel)

local actionPanel = make("Frame", {
	Name = "TouchActions",
	AnchorPoint = Vector2.new(1, 1),
	Position = UDim2.new(1, -18, 1, -18),
	Size = UDim2.fromOffset(236, 234),
	BackgroundTransparency = 1,
	Visible = UserInputService.TouchEnabled,
}, gui)

make("UIGridLayout", {
	CellSize = UDim2.fromOffset(72, 68),
	CellPadding = UDim2.fromOffset(7, 7),
	FillDirectionMaxCells = 3,
	SortOrder = Enum.SortOrder.LayoutOrder,	
}, actionPanel)

local function makeActionButton(name, text, order, color, callback, hold)
	local button = make("TextButton", {
		Name = name,
		Text = text,
		TextColor3 = palette.Text,
		TextSize = 11,
		Font = Enum.Font.GothamBold,
		BackgroundColor3 = color,
		BackgroundTransparency = 0.08,
		BorderSizePixel = 0,
		AutoButtonColor = true,
		LayoutOrder = order,
	}, actionPanel)
	round(button, 12)
	stroke(button, Color3.fromRGB(220, 226, 255), 0.78, 1)
	if hold then
		button.InputBegan:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
				callback(true)
			end
		end)
		button.InputEnded:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
				callback(false)
			end
		end)
	else
		button.Activated:Connect(callback)
	end
	return button
end

makeActionButton("Light", "LEVE", 1, Color3.fromRGB(45, 105, 152), function() CombatRequest:FireServer("Light") end)
makeActionButton("Heavy", "PESADO", 2, Color3.fromRGB(118, 73, 78), function() CombatRequest:FireServer("Heavy") end)
makeActionButton("Block", "DEFESA", 3, Color3.fromRGB(76, 91, 114), function(started)
	CombatRequest:FireServer(started and "BlockStart" or "BlockEnd")
end, true)
makeActionButton("Dodge", "ESQUIVA", 4, Color3.fromRGB(73, 105, 94), function() CombatRequest:FireServer("Dodge") end)
makeActionButton("Skill", "TÉCNICA", 5, Color3.fromRGB(117, 71, 132), function() CombatRequest:FireServer("Skill") end)
makeActionButton("Train", "TREINO", 6, Color3.fromRGB(124, 96, 54), function() TrainRequest:FireServer() end)
makeActionButton("Quest", "PROVA", 7, Color3.fromRGB(125, 91, 58), function() QuestRequest:FireServer("AcceptTrial") end)

local pcHints = make("TextLabel", {
	Name = "DesktopHints",
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -18, 0, 18),
	Size = UDim2.fromOffset(190, 92),
	BackgroundColor3 = palette.Panel,
	BackgroundTransparency = 0.24,
	BorderSizePixel = 0,
	Text = "M1  Ataque leve\nM2  Ataque pesado\nF  Bloquear\nQ  Esquiva\nE  Técnica\nT  Treinar  ·  G  Prova",
	TextColor3 = palette.Muted,
	TextSize = 11,
	TextXAlignment = Enum.TextXAlignment.Left,
	TextYAlignment = Enum.TextYAlignment.Center,
	Font = Enum.Font.Gotham,
	Visible = not UserInputService.TouchEnabled,
}, gui)
round(pcHints, 10)

local message = make("TextLabel", {
	Name = "WorldMessage",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 30),
	Size = UDim2.new(0.7, 0, 0, 42),
	BackgroundColor3 = palette.Panel,
	BackgroundTransparency = 1,
	TextTransparency = 1,
	Text = "",
	TextColor3 = palette.Gold,
	TextScaled = true,
	Font = Enum.Font.GothamBold,
	Visible = false,
}, gui)
round(message, 12)
stroke(message, palette.Gold, 0.55, 1)

local factionScreen = make("Frame", {
	Name = "FactionSelection",
	Size = UDim2.fromScale(1, 1),
	BackgroundColor3 = Color3.fromRGB(9, 10, 18),
	BackgroundTransparency = 0.08,
	BorderSizePixel = 0,
	Visible = false,
	ZIndex = 20,
}, gui)

local selectionPanel = make("Frame", {
	Name = "SelectionPanel",
	AnchorPoint = Vector2.new(0.5, 0.5),
	Position = UDim2.fromScale(0.5, 0.5),
	Size = UDim2.new(0.9, 0, 0, 350),
	BackgroundColor3 = palette.Panel,
	BorderSizePixel = 0,
	ZIndex = 21,
}, factionScreen)
round(selectionPanel, 18)
stroke(selectionPanel, palette.Gold, 0.55, 1)

make("TextLabel", {
	Name = "SelectionTitle",
	Position = UDim2.fromOffset(18, 18),
	Size = UDim2.new(1, -36, 0, 44),
	BackgroundTransparency = 1,
	Text = "ESCOLHA SEU CAMINHO",
	TextColor3 = palette.Gold,
	TextScaled = true,
	Font = Enum.Font.GothamBlack,
	ZIndex = 22,
}, selectionPanel)

make("TextLabel", {
	Name = "SelectionSubtitle",
	Position = UDim2.fromOffset(24, 66),
	Size = UDim2.new(1, -48, 0, 32),
	BackgroundTransparency = 1,
	Text = "Sua decisão define estilo, missão e forma de lutar.",
	TextColor3 = palette.Muted,
	TextWrapped = true,
	TextSize = 13,
	Font = Enum.Font.Gotham,
	ZIndex = 22,
}, selectionPanel)

local function factionButton(name, display, description, y, color, faction)
	local button = make("TextButton", {
		Name = name,
		Position = UDim2.fromOffset(22, y),
		Size = UDim2.new(1, -44, 0, 98),
		BackgroundColor3 = color,
		BackgroundTransparency = 0.14,
		BorderSizePixel = 0,
		Text = "",
		ZIndex = 22,
	}, selectionPanel)
	round(button, 13)
	stroke(button, color, 0.15, 2)
	make("TextLabel", {
		Position = UDim2.fromOffset(16, 10),
		Size = UDim2.new(1, -32, 0, 30),
		BackgroundTransparency = 1,
		Text = display,
		TextColor3 = palette.Text,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextSize = 20,
		Font = Enum.Font.GothamBlack,
		ZIndex = 23,
	}, button)
	make("TextLabel", {
		Position = UDim2.fromOffset(16, 43),
		Size = UDim2.new(1, -32, 0, 42),
		BackgroundTransparency = 1,
		Text = description,
		TextColor3 = palette.Text,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextWrapped = true,
		TextSize = 12,
		Font = Enum.Font.Gotham,
		ZIndex = 23,
	}, button)
	button.Activated:Connect(function()
		FactionRequest:FireServer(faction)
	end)
end

factionButton("GuardianChoice", "GUARDIÃO  ·  ESCOLA DA MARÉ", "Lâmina, precisão e contra-ataques. Habilidade: Corte da Maré.", 112, Color3.fromRGB(48, 105, 147), "Guardiao")
factionButton("CreatureChoice", "CRIATURA  ·  ARTE DO ABISMO", "Poder sobrenatural e pressão de perto. Habilidade: Pulso Abissal.", 220, Color3.fromRGB(115, 55, 92), "Criatura")

local function setBar(fill, value, maximum)
	local ratio = maximum > 0 and math.clamp(value / maximum, 0, 1) or 0
	fill.Size = UDim2.fromScale(ratio, 1)
end

local function updateQuest(quest)
	if not quest or quest.Completed then
		questText.Text = quest and quest.Completed and "Prova concluída. Explore o bosque e desafie a Sentinela." or "Aceite a prova e derrote 3 Sombras Errantes."
	elseif quest.Active then
		questText.Text = "Derrote Sombras Errantes: " .. quest.Progress .. "/" .. quest.Goal
	else
		questText.Text = "Aceite a prova para começar: 3 Sombras Errantes."
	end
end

StateUpdate.OnClientEvent:Connect(function(state)
	identity.Text = "Nível " .. tostring(state.Level) .. "  ·  " .. tostring(state.FactionName)
	rankLabel.Text = tostring(state.Rank) .. "  ·  " .. tostring(state.StyleName) .. "  ·  Domínio " .. tostring(state.Mastery)
	setBar(healthFill, state.Health or 0, state.MaxHealth or 100)
	setBar(energyFill, state.Energy or 0, state.MaxEnergy or Config.MaxEnergy)
	setBar(xpFill, state.XP or 0, state.XPToNext or 100)
	saveLabel.Text = state.DataPersistent and "Dados persistentes ativos" or "Sessão temporária · salvamento indisponível"
	saveLabel.TextColor3 = state.DataPersistent and palette.Green or palette.Gold
	updateQuest(state.Quest)
	factionScreen.Visible = state.Faction == nil
end)

local messageSerial = 0
local function showMessage(text)
	messageSerial += 1
	local serial = messageSerial
	message.Text = tostring(text)
	message.Visible = true
	message.BackgroundTransparency = 0.18
	message.TextTransparency = 0
	task.delay(2.8, function()
		if serial ~= messageSerial then
			return
		end
		local tween = TweenService:Create(message, TweenInfo.new(0.45), { BackgroundTransparency = 1, TextTransparency = 1 })
		tween:Play()
		tween.Completed:Connect(function()
			if serial == messageSerial then
				message.Visible = false
			end
		end)
	end)
end

WorldMessage.OnClientEvent:Connect(showMessage)

local function makePulse(position, radius, color, duration, transparency)
	local pulse = Instance.new("Part")
	pulse.Name = "EclipseLocalEffect"
	pulse.Shape = Enum.PartType.Cylinder
	pulse.Size = Vector3.new(0.22, 1, 1)
	pulse.CFrame = CFrame.new(position.X, position.Y + 0.18, position.Z) * CFrame.Angles(0, 0, math.rad(90))
	pulse.Anchored = true
	pulse.CanCollide = false
	pulse.CanQuery = false
	pulse.CanTouch = false
	pulse.Material = Enum.Material.Neon
	pulse.Color = color
	pulse.Transparency = transparency or 0.35
	pulse.Parent = workspace

	local tween = TweenService:Create(pulse, TweenInfo.new(duration, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Size = Vector3.new(0.22, radius * 2, radius * 2),
		Transparency = 1,
	})
	tween:Play()
	Debris:AddItem(pulse, duration + 0.2)
end

CombatFeedback.OnClientEvent:Connect(function(kind, position, radius, faction)
	if typeof(position) ~= "Vector3" then
		return
	end

	if kind == "boss_windup" then
		makePulse(position, radius or 16, Color3.fromRGB(240, 57, 91), 1.12, 0.55)
	elseif kind == "enemy_windup" then
		makePulse(position, radius or 6, Color3.fromRGB(255, 157, 89), 0.55, 0.65)
	elseif kind == "boss_slam" then
		makePulse(position, radius or 16, Color3.fromRGB(255, 90, 115), 0.34, 0.25)
	elseif kind == "tide_skill" then
		makePulse(position, math.max(8, radius or 11), Color3.fromRGB(79, 190, 255), 0.5, 0.2)
	elseif kind == "abyss_skill" then
		makePulse(position, math.max(8, radius or 11), Color3.fromRGB(204, 76, 177), 0.5, 0.2)
	elseif kind == "hit" or kind == "enemy_hit" or kind == "enemy_defeated" or kind == "boss_defeated" then
		makePulse(position, kind == "boss_defeated" and 12 or 4, Color3.fromRGB(255, 221, 157), 0.28, 0.3)
	elseif kind == "dash" or kind == "dodge" then
		makePulse(position, 4, Color3.fromRGB(151, 210, 255), 0.22, 0.58)
	elseif kind == "attack_windup" then
		local color = faction == "Criatura" and palette.Red or palette.Blue
		makePulse(position, 3.5, color, 0.18, 0.75)
	end
end)

UserInputService.InputBegan:Connect(function(input, processed)
	if processed or factionScreen.Visible then
		return
	end
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		CombatRequest:FireServer("Light")
	elseif input.UserInputType == Enum.UserInputType.MouseButton2 then
		CombatRequest:FireServer("Heavy")
	elseif input.KeyCode == Enum.KeyCode.F then
		CombatRequest:FireServer("BlockStart")
	elseif input.KeyCode == Enum.KeyCode.Q then
		CombatRequest:FireServer("Dodge")
	elseif input.KeyCode == Enum.KeyCode.E then
		CombatRequest:FireServer("Skill")
	elseif input.KeyCode == Enum.KeyCode.T then
		TrainRequest:FireServer()
	elseif input.KeyCode == Enum.KeyCode.G then
		QuestRequest:FireServer("AcceptTrial")
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.KeyCode == Enum.KeyCode.F then
		CombatRequest:FireServer("BlockEnd")
	end
end)

local function bindGamepad(name, keyCode, action, hold)
	ContextActionService:BindAction(name, function(_, state)
		if factionScreen.Visible then
			return Enum.ContextActionResult.Pass
		end
		if hold then
			if state == Enum.UserInputState.Begin then
				CombatRequest:FireServer("BlockStart")
			elseif state == Enum.UserInputState.End or state == Enum.UserInputState.Cancel then
				CombatRequest:FireServer("BlockEnd")
			end
		elseif state == Enum.UserInputState.Begin then
			if action == "Train" then
				TrainRequest:FireServer()
			elseif action == "Quest" then
				QuestRequest:FireServer("AcceptTrial")
			else
				CombatRequest:FireServer(action)
			end
		end
		return Enum.ContextActionResult.Sink
	end, false, keyCode)
end

bindGamepad("EclipseLight", Enum.KeyCode.ButtonR2, "Light", false)
bindGamepad("EclipseHeavy", Enum.KeyCode.ButtonX, "Heavy", false)
bindGamepad("EclipseBlock", Enum.KeyCode.ButtonL2, "Block", true)
bindGamepad("EclipseDodge", Enum.KeyCode.ButtonB, "Dodge", false)
bindGamepad("EclipseSkill", Enum.KeyCode.ButtonY, "Skill", false)
bindGamepad("EclipseQuest", Enum.KeyCode.DPadUp, "Quest", false)

player.CharacterAdded:Connect(function()
	CombatRequest:FireServer("BlockEnd")
end)

