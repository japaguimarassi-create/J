local Config = {}

Config.GameName = "ECLIPSE: BLOOD & BREATH"
Config.ProfileVersion = 1
Config.DataStoreName = "EclipsePlayerData_v1"
Config.MaxEnergy = 100
Config.EnergyRegenPerSecond = 8
Config.TrainingCooldown = 4
Config.QuestGoal = 3

Config.RemoteNames = {
	"CombatRequest",
	"FactionRequest",
	"TrainRequest",
	"QuestRequest",
	"StateUpdate",
	"CombatFeedback",
	"WorldMessage",
}

Config.Factions = {
	Guardiao = {
		DisplayName = "Guardião",
		StyleName = "Escola da Maré",
		SkillName = "Corte da Maré",
		Color = Color3.fromRGB(93, 190, 255),
		Description = "Disciplina, lâmina e contra-ataques precisos.",
	},
	Criatura = {
		DisplayName = "Criatura",
		StyleName = "Arte do Abismo",
		SkillName = "Pulso Abissal",
		Color = Color3.fromRGB(205, 83, 178),
		Description = "Poder inato, pressão de área e regeneração limitada.",
	},
}

Config.Ranks = {
	{ Name = "Recruta", Level = 1 },
	{ Name = "Vigia", Level = 3 },
	{ Name = "Patrulheiro", Level = 6 },
	{ Name = "Lâmina Inicial", Level = 10 },
	{ Name = "Lâmina Juramentada", Level = 15 },
	{ Name = "Sentinela", Level = 22 },
	{ Name = "Veterano", Level = 30 },
	{ Name = "Mestre de Campo", Level = 40 },
	{ Name = "Guardião Supremo", Level = 55 },
	{ Name = "Lenda da Ordem", Level = 75 },
}

Config.Combat = {
	Light = {
		Cooldown = 0.42,
		Startup = 0.12,
		Recovery = 0.22,
		Damage = 13,
		Range = 7,
		Width = 6,
		Height = 5,
	},
	Heavy = {
		Cooldown = 1.15,
		Startup = 0.38,
		Recovery = 0.42,
		Damage = 27,
		Range = 8,
		Width = 8,
		Height = 6,
	},
	Skill = {
		Cooldown = 7,
		Startup = 0.48,
		Recovery = 0.52,
		Damage = 39,
		EnergyCost = 35,
		Range = 13,
		Radius = 11,
	},
	Dodge = {
		Cooldown = 1.05,
		EnergyCost = 12,
		Speed = 64,
		Duration = 0.24,
	},
	BlockDamageMultiplier = 0.38,
}

Config.Enemies = {
	Common = {
		Name = "Sombra Errante",
		Health = 90,
		Damage = 9,
		WalkSpeed = 12,
		AttackRange = 6.5,
		AttackCooldown = 2.1,
		RespawnTime = 12,
		XP = 26,
		Gold = 9,
		Color = Color3.fromRGB(75, 76, 105),
	},
	Boss = {
		Name = "Sentinela da Fenda",
		Health = 520,
		Damage = 24,
		WalkSpeed = 10,
		AttackRange = 13,
		AttackCooldown = 6.5,
		RespawnTime = 55,
		XP = 160,
		Gold = 85,
		Color = Color3.fromRGB(132, 55, 92),
	},
}

return Config
